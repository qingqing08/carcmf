-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : car
-- 
-- Part : #1
-- Date : 2020-03-19 10:57:59
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `c_banner`
-- -----------------------------
DROP TABLE IF EXISTS `c_banner`;
CREATE TABLE `c_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据id',
  `data_id` int(11) DEFAULT '0' COMMENT '数据ID',
  `image` varchar(200) DEFAULT '' COMMENT '图片地址',
  `type` int(11) DEFAULT '0' COMMENT '类型：1产品2实训室3案例',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='轮播图表';

-- -----------------------------
-- Records of `c_banner`
-- -----------------------------
INSERT INTO `c_banner` VALUES ('1', '2', '/upload/banner/image/62/aaaba56b3e4b5f3f656f68bb1fd2d7.jpg', '2', '1584417175');
INSERT INTO `c_banner` VALUES ('2', '7', '/upload/banner/image/65/f983115e044dcd7625e908c91b7c99.jpg', '2', '1584417164');
INSERT INTO `c_banner` VALUES ('3', '3', '/upload/banner/image/ef/a658af4d6104ea76c365561ff92906.jpg', '2', '1584417142');

-- -----------------------------
-- Table structure for `c_case`
-- -----------------------------
DROP TABLE IF EXISTS `c_case`;
CREATE TABLE `c_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `category_id` int(11) DEFAULT '0' COMMENT '分类ID',
  `title` varchar(100) DEFAULT '' COMMENT '案例标题',
  `image` varchar(100) DEFAULT '' COMMENT '案例主图',
  `content` text COMMENT '详细内容',
  `fabulous_number` int(11) NOT NULL DEFAULT '0',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='案例表';

-- -----------------------------
-- Records of `c_case`
-- -----------------------------
INSERT INTO `c_case` VALUES ('1', '1', '山东聊城汽车智慧教学实训室', '/upload/case/image/5b/9933095aa469d4cd11b63847cbcb7f.jpg', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/b3/bf79e8f40ae7852ee156808b1b7443.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 聊城汽车实训室设置了从中低档到高档车的全面整车实训车间，以及个基础部件的配合实训车间，如，别克、大众、丰田、迈腾、宝马等实训车间，以及电子电工、防盗系统等实训车间，全面系统化的实训车间。且设备采用二维码在线教学系统，可用于老师在线教学和学生自学复习。&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/e1/5a0e932d0dc42aea909ac75e8ded39.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/5f/9e4d07be2421cc6f2a65bd2ad0689d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/f9/5ba4f975422bae2f1d66ae98f4929c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/91/a418d424216c1ce0ed912802532c6e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;', '2', '1584416398');
INSERT INTO `c_case` VALUES ('2', '2', '河南郑州智慧教学实训室', '/upload/case/image/40/c9ed7e892f0438f534fe7a29bd4c6f.jpg', '&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 郑州汽车实训室，由奔驰实训车间、 宝马实训车间、 奥迪实训车间、美容实训车间等多部分组成，每个实训车间都配备了诊断仪器,资料数据库等内容，设备采用二维码在线教学系统，基于智能化环境运行，可用于老师在线教学和学生自学复习，适用于对汽车整车教学和维修实训的教学需要。&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;本着精益求精、务实创新的精神，中职北方研究所由1996年创立之初研发的第一代教学模型发展到如今的第九代教学实验模型，为广大汽修同仁及各大大中院校提供了完备的实训室建设方案。&lt;/p&gt;', '2', '1584416437');
INSERT INTO `c_case` VALUES ('3', '1', '滨州技师学院智慧教学实训室', '/upload/case/image/0c/3ee16997e7b82c7c36411325b7eeec.jpg', '&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/80/66bb5f2716a85ac3c88082be426b99.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 滨州市技师学院坐落在黄河三角洲流域的的董永故里，全国经济百强县——博兴，是经山东省人民政府批准建立的目前滨州市唯一一所以培养社会紧缺的技师、高级技工等高技能人才为主的国办全日制普通高等职业教育院校。&amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/7a/ee344ed90950d4e2f1d6e39627c9e2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/d7/25027201b6116c1aa8e436fa7d3243.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/3f/b99484689859c982b6dfd597c45e90.jpg&quot; alt=&quot;undefined&quot;&gt;&amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/34/0d3d561bb60e532f6ce5857c9954b8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/26/088f99f71b721b1cbd02b95a480abf.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/41/63c1b2908df503c85527a7bd3fc4a6.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/cf/1793ce1c62028829ac6ab0439196e1.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/3d/a1f0c50c743325a864cb9d30436f67.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/43/da813436a69132eaadaa308a454fc8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/64/2c01396a3cb012dd5f262fd9ec770d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/a6/2943561f679f076a79c341a0147dce.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/34/8aeb6c28f3e24c0b162c165eb595cd.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/b1/e9efde1b7fc1d77480301765144835.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/82/fa1f3b2cecaa1df7e33b897f39862d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/19/7942c07e36c0e6754e95a3285ef69b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/03/14c64f01afc03602c6b0f3aa744173.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/bf/c56814474a29d6dea7e94326f07744.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/57/222ac8202941f09e2b0c11bf0337eb.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/d7/ecba6f7f63cbb0518e47f2c8dd28a3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/62/54de3be7306b92d339e6be0a9a767d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/9a/9ee24c5071fc0048dcf134e1472f5b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/47/d3ac1b0c9e11ab59f78af1964b24df.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; &quot;&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;', '2', '1584416131');
INSERT INTO `c_case` VALUES ('4', '6', '广元市职业高级中学智慧教学实训室', '/upload/case/image/10/7fa036077eccd349470ea08a11520a.jpg', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/e1/5dfde508fb174cc86c38dd48033ac8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 四川省广元市职业高级中学校创办于1985年，前身为广元市轻化工业技工学校，2004年与市旅游职业技术学校（原商业技校）整合，2007年进入教育园区，直属广元市教育局，是集学历教育、职业技能培训与鉴定和就业指导服务于一体的现代化职业学校。为国家级重点中等职业学校，国家中等职业教育改革发展示范学校，藏区“9+3”免费教育计划实施学校，四川省教育体制改革试点项目“产教融合机制建设”重点学校。&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/13/086ca6124701ea17719ea2e198c75e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/77/2027f2e6bee2a65ffd716bdf3a74ce.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/39/618cb53720b2ff8566095ae35e0b07.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/59/b431537e728fc4ff6b59a699710066.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/be/08e5a04e73f438bf68a5edb2616341.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/d2/3710fb93cbb959cc825154a8812110.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/c7/8a59e018865ddbf62f4c1072a9a547.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/0a/c65d6f5c7aab4a528ea3f5f78fe34a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/bd/fcb290fc2c74dcaf1cdc8e1da97005.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/c0/ef71eb15d4e4ad189f60fede2f2406.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/73/18c57971314d6cd6e708ca4ec21eb6.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/90/3f62c46eaf769403707da2db830f3a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;', '2', '1584423808');
INSERT INTO `c_case` VALUES ('5', '5', '吉林大学智慧教学实训室', '/upload/case/image/0a/d449e60d8453d8fdb291040bafea98.jpg', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/6e/c308f30fae3ebd76e5745bc75ac62e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 吉林大学汽车工程学院成立于1955年，其车辆工程学科是国内汽车领域最早的国家级重点学科，拥有汽车仿真与控制国家重点实验室。汽车学院拥有以中国工程院院士郭孔辉教授为核心的200多名教师组成的教学和科研队伍，创新研发了一系列先进设计理论、技术方法、软件平台和重大实验装备，为我国主要汽车企业的自主创新能力建设做出了重要贡献。&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/ec/29e9d47084a36c8bdd3510257e1c98.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/3d/2e2aa519c4153bb077ee3e32489407.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/e0/6c0c8cb0fc01b7a3f2787c595225e2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/4a/f33b0276c458c1c6cdd5c887f7b24d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/44/802e8cae2d443760b9b2dc8b03b3de.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/case/image/4f/21ff51ec32848dfdf24a116b6df0a1.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;', '2', '1584416121');

-- -----------------------------
-- Table structure for `c_case_category`
-- -----------------------------
DROP TABLE IF EXISTS `c_case_category`;
CREATE TABLE `c_case_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `category_name` varchar(100) DEFAULT '' COMMENT '分类名称',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `c_case_category`
-- -----------------------------
INSERT INTO `c_case_category` VALUES ('1', '华北地区', '1584004686');
INSERT INTO `c_case_category` VALUES ('2', '华南地区', '1584003396');
INSERT INTO `c_case_category` VALUES ('3', '华东地区', '1584003406');
INSERT INTO `c_case_category` VALUES ('4', '华中地区', '1584003415');
INSERT INTO `c_case_category` VALUES ('5', '东北地区', '1584004701');
INSERT INTO `c_case_category` VALUES ('6', '西南地区', '1584414565');

-- -----------------------------
-- Table structure for `c_comment`
-- -----------------------------
DROP TABLE IF EXISTS `c_comment`;
CREATE TABLE `c_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '点赞ID',
  `user_id` int(11) DEFAULT '0' COMMENT '点赞人',
  `data_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '1产品2实训室3案例4视频',
  `content` text COMMENT '评论内容',
  `c_time` varchar(11) DEFAULT '' COMMENT '点赞时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='评论表';

-- -----------------------------
-- Records of `c_comment`
-- -----------------------------
INSERT INTO `c_comment` VALUES ('1', '3', '1', '2', '测试评论测试测试测试', '1584526195');
INSERT INTO `c_comment` VALUES ('2', '1', '10', '2', '测试', '1584526459');
INSERT INTO `c_comment` VALUES ('3', '1', '10', '2', '测试123', '1584526464');
INSERT INTO `c_comment` VALUES ('4', '1', '10', '2', '321', '1584526598');
INSERT INTO `c_comment` VALUES ('5', '1', '10', '2', '321', '1584526605');
INSERT INTO `c_comment` VALUES ('6', '1', '10', '2', '321', '1584526609');
INSERT INTO `c_comment` VALUES ('7', '1', '1', '2', '123', '1584527004');
INSERT INTO `c_comment` VALUES ('8', '3', '2', '2', '测试评论测试测试测试', '1584527086');
INSERT INTO `c_comment` VALUES ('9', '1', '1', '2', '321', '1584527110');
INSERT INTO `c_comment` VALUES ('10', '1', '1', '2', '新评论', '1584527149');
INSERT INTO `c_comment` VALUES ('11', '1', '2', '2', '', '1584581370');
INSERT INTO `c_comment` VALUES ('12', '1', '11', '2', '', '1584582453');
INSERT INTO `c_comment` VALUES ('13', '1', '11', '2', '', '1584582455');
INSERT INTO `c_comment` VALUES ('14', '1', '11', '2', '123', '1584582494');
INSERT INTO `c_comment` VALUES ('15', '1', '11', '2', 'test', '1584582546');
INSERT INTO `c_comment` VALUES ('16', '1', '2', '4', '测试', '1584582731');
INSERT INTO `c_comment` VALUES ('17', '1', '2', '4', '123测试评论', '1584583028');

-- -----------------------------
-- Table structure for `c_company`
-- -----------------------------
DROP TABLE IF EXISTS `c_company`;
CREATE TABLE `c_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `content` text COMMENT '公司简介',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='公司介绍表';

-- -----------------------------
-- Records of `c_company`
-- -----------------------------
INSERT INTO `c_company` VALUES ('1', '&lt;p style=&quot;text-align: left;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 北方职业教育研究院隶属于中国北方国际汽车教育集团，致力于汽车教育装备27年，是国内最大生产规模，研发实力最强的汽车教育整体解决方案供应商。      提供实训室整体设计、教具研发、智造、课程体系、师资培训、教材编撰、学生创就业体系。&lt;/p&gt;&lt;p style=&quot;text-align: left;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;引进德国双元制教育体系，结合中国职业教育特点，研发适合中国国情的课程体系和教育装备。&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 912项专利技术，涵盖教具研发、智造，课程体系设计，课件编制，网络学习、软件开发等汽车教育所需。&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 与中国汽车技术研究中心和教育部职教司合作，为300多家中高职院提供服务和产品。      教具行业唯一装备两条自动流水线的智造厂家，8000台的年生产能力，可以满足从整车到部件，从中职到211、985所需的服务和产品。&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p style=&quot;text-align: left;&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/company/image/f6/4caa4a0629e596df6b05c9689d70fa.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;全流程交钥匙工程&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 1、系统规划：立足国际国内最优秀汽车职业体系系统规划；&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 2、主题装修：融汽车科技、工业文化、艺术设计等主题设计；&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 3、专项研发：立足当地市场，弥补需方劣势；&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 4、快速生产：七日交验；&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 5、专业安装：专业队伍、专属标准；&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 6、精准调试：硬件、软件、网络体系互融互通；&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 7、延伸服务：师资培训、技能充电、体系升级、网点支撑；&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; （分布全国的学校都是你的服务网点、赋能网点）&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;', '1584430515');
INSERT INTO `c_company` VALUES ('2', '&lt;p style=&quot;text-align: center;&quot;&gt;地址：河北省邯郸市广平县开发区昆山路中北教具基地&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;电话：0310-2519888&amp;nbsp; 15831036208&amp;nbsp;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;QQ：38090539&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;邮箱：touchbon@163.com&lt;/p&gt;', '1584434369');

-- -----------------------------
-- Table structure for `c_fabulous`
-- -----------------------------
DROP TABLE IF EXISTS `c_fabulous`;
CREATE TABLE `c_fabulous` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '点赞ID',
  `user_id` int(11) DEFAULT '0' COMMENT '点赞人',
  `data_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '1产品2实训室3案例4视频',
  `c_time` varchar(11) DEFAULT '' COMMENT '点赞时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='点赞表';

-- -----------------------------
-- Records of `c_fabulous`
-- -----------------------------
INSERT INTO `c_fabulous` VALUES ('1', '2', '1', '3', '1584520921');
INSERT INTO `c_fabulous` VALUES ('2', '2', '1', '3', '1584521025');
INSERT INTO `c_fabulous` VALUES ('3', '3', '1', '3', '1584521290');
INSERT INTO `c_fabulous` VALUES ('4', '1', '1', '2', '1584523259');
INSERT INTO `c_fabulous` VALUES ('5', '1', '2', '2', '1584523675');
INSERT INTO `c_fabulous` VALUES ('6', '1', '3', '2', '1584523756');
INSERT INTO `c_fabulous` VALUES ('7', '1', '10', '2', '1584526013');
INSERT INTO `c_fabulous` VALUES ('8', '1', '2', '4', '1584582720');
INSERT INTO `c_fabulous` VALUES ('9', '1', '3', '4', '1584583075');

-- -----------------------------
-- Table structure for `c_feedback`
-- -----------------------------
DROP TABLE IF EXISTS `c_feedback`;
CREATE TABLE `c_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '反馈ID',
  `uid` int(11) DEFAULT '0' COMMENT '用户ID',
  `name` varchar(100) DEFAULT '' COMMENT '姓名',
  `tel` varchar(11) DEFAULT '' COMMENT '电话',
  `email` varchar(20) DEFAULT '' COMMENT '邮箱',
  `title` varchar(100) DEFAULT '' COMMENT '反馈标题',
  `content` text COMMENT '反馈内容',
  `c_time` varchar(11) DEFAULT '' COMMENT '反馈时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='反馈表';

-- -----------------------------
-- Records of `c_feedback`
-- -----------------------------
INSERT INTO `c_feedback` VALUES ('1', '0', '晴晴', '17600969308', '2538668046@qq.com', '测试反馈标题', '反馈反馈反馈反馈反馈反馈反馈反馈', '1584174673');
INSERT INTO `c_feedback` VALUES ('2', '0', '1', '13730012345', '309464658@qq.com', '4', '5', '1584176415');
INSERT INTO `c_feedback` VALUES ('3', '0', '1', '13730012345', '309464658@qq.com', '4', '5', '1584176431');
INSERT INTO `c_feedback` VALUES ('4', '0', '1', '13730012345', '309464658@qq.com', '4', '5', '1584176434');

-- -----------------------------
-- Table structure for `c_jobs`
-- -----------------------------
DROP TABLE IF EXISTS `c_jobs`;
CREATE TABLE `c_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `c_laboratory`
-- -----------------------------
DROP TABLE IF EXISTS `c_laboratory`;
CREATE TABLE `c_laboratory` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `category_id` int(11) DEFAULT '0' COMMENT '分类ID',
  `laboratory_name` varchar(100) DEFAULT '' COMMENT '实验室名称',
  `image` varchar(150) DEFAULT '' COMMENT '主图片地址',
  `introduction` varchar(500) DEFAULT '' COMMENT '简介',
  `video` varchar(150) DEFAULT NULL COMMENT '视频地址',
  `file` varchar(150) DEFAULT NULL COMMENT '文件地址',
  `content` text COMMENT '详情介绍',
  `share_number` int(11) DEFAULT '0' COMMENT '分享次数',
  `fabulous_number` int(11) DEFAULT '0' COMMENT '点赞次数',
  `is_wisdom` int(11) DEFAULT '0' COMMENT '是否是智慧实验室1是0不是',
  `watch_number` int(11) DEFAULT '0' COMMENT '观看次数',
  `c_time` varchar(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='实验室表';

-- -----------------------------
-- Records of `c_laboratory`
-- -----------------------------
INSERT INTO `c_laboratory` VALUES ('1', '7', '奥迪智慧实训室', '/upload/laboratory/image/ae/f9074e441f6ba1b18f2fc6eee9f5e0.jpg', '以奥迪A6L发动机实物为基础，由主台架、控制检测面板两部分组成。适用于汽油发动机构造与维修实训教学，能够满足对汽油发动机的结构、工作原理、故障设置及诊断的教学需要。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200316/58b8899030ba271f3b5bd93a98a2ba89.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/26/1641fb549d3b3197a9fde99cfcfaa2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/97/d4f00ca4e975c9da04a0c02e1e17f0.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/0b/6656acb9dd2f4ecd3f885eb988cd01.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6a/c975f6a85edb906029fdcc43b91744.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/58/b898518f0bfad396d8889c76f3d55c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e4/f363af86f1dbd74e1e03b2bcdc529e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/79/b157423c023a82bf175b7419cd9cc0.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/29/abba6d6f60a8a584f02a7fc855de03.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/d8/76a9e758847eb20226a40d0cddbd92.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/04/01cab4edd46ecdabcc56b2d89ff337.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e3/19ca98b92822775bdacbf10c2629b4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6f/8b3d6fae61cbea723124cdd9181aa9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/a1/4c26843371fd728c89e41e01ee1545.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/81/f95b3b13113ab6f0e186a7fd0624d8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/90/5b85c1b03923b2191e4c4a71d993e2.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '1', '308', '1584583405');
INSERT INTO `c_laboratory` VALUES ('2', '4', '特斯拉纯电动智慧实训室', '/upload/laboratory/image/b0/aa130286e7fd78f3f5ec2ce497395c.jpg', '2017年5月 发动机 ：纯电动387马力电动机 变速箱：电动车单速变速箱 车身类型：5门5坐掀背车 长*宽*高：4970*1964*1445 轴距：2960 最高车速：225该汽车外加整车实训台示教板面板上安装有检测端子，采用无损32针插头链接汽车仪表及仪表传感器与外部灯光系统、发动机系统可直接在面板上检测汽车仪表与外部灯光系统各电路元件的电信号，如电阻、电压、电流、频率信号等。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200316/eeb769c2d75b80f91381abcb8a4f5395.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/b4/522cc9b9767eefcc00865ad7fdfbb7.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/c6/bc0d0b34654b1f1fbbd1e17eb8e1f4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/b0/2d32a86364ea25697f7851ad6f719c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/63/30bf786d7c2c0549ac5085fbe29c18.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/52/84e18b2b81862ddd467e552f07d9e9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/76/fba63d92367e48a801e3e9fc712879.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/b8/40b7f5b54f5d94b42f1c1b1ec450e7.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/18/7ffe85a241748959c63c2c9705db00.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/bf/6e2a5bf0ec3ed81717198a1b21310c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/46/dec3080656fc579669bbfe4845d1b4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f4/7798946bb0691b519087c78db1f428.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '1', '308', '1584583341');
INSERT INTO `c_laboratory` VALUES ('3', '7', '宝马智慧实训室', '/upload/laboratory/image/46/677ff714add0977810c3ab76f79e03.jpg', '以宝马17款宝马5系2.0T发动机+变速器实物为基础，由主台架、控制检测面板两部分组成。适用于汽油发动机构造与维修实训教学，能够满足对汽油发动机的结构、工作原理、故障设置及诊断的教学需要。', '', '/upload/laboratory/file/20200316/f51fd0d2959271d002736fdfbe409965.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/a0/d598f692165dc453f14b5a4cae903b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/d0/762240109a074dff5b8ea4d1ec6aa8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/2b/ef40839434398069715ba00c4a3fe2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f6/fb38ffa99c8d07fa404024054ea238.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/4a/04b0c896cd39e26b89aec1a9135fd3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/1a/a7f638b4bb1e2776fae1e2957acfee.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/78/53eb7a255718a2ee160b903014814c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/8f/a34fbfe8d1f00b6ed4e839e041e487.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/68/f0dea923455703a93c8ad4144b0cef.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/07/7cad4017e6290ceb53c182b565c67d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/1c/5ca4000df5b96e9104bdd2c45c93a3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/c4/913089c6252ce326b11571f17c569b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/42/7bba4fdbf50744abfc99c2a3fdbf19.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/2a/5a3c95592465d32294c3a00fcf6ec3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f2/1ea800e8a078110f2832f02521c626.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '1', '202', '1584353376');
INSERT INTO `c_laboratory` VALUES ('4', '4', '北汽纯电动实训室', '/upload/laboratory/image/f4/13d14b22a8a39b2f066356d098ac61.jpg', '设备采用北汽EV160纯电动整车改造制作而成, 在保持原车钣金、机械、电器、电池组各个系统相对完整的基础上，对车身覆盖件和车架的关键部位进行合理解剖,展示系统的内部结构。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200316/a9e5802f933f113dd1fee7cbb11b7525.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/eb/aec03f1a7eab2d6a1200feb9a48b61.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/89/7b07619845a2d453f4fb259ad29d23.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/12/44d3c1201ee9fa76684c0a9c24a2fa.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/23/08fad3ece780bedbe8b5b9ce543192.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e6/7686ea7769b047ed52f01570363e8b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/45/a0d9cc1d6f67bde4e8de37fabd46cc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/49/f7c9b459f743d72a9a0b1015cd1889.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/04/0516e2e8107206e7b11a60b02e3a40.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/2f/8325e7dd1f7276cb7176f50704094a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/1a/420fdb945978048f82e2389917530d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/0d/751a1054e6d4b2b069a756e9604864.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '1', '201', '1584583355');
INSERT INTO `c_laboratory` VALUES ('5', '7', '奔驰智慧实训室', '/upload/laboratory/image/5a/e5f794db861c9e15b0f439064f8cea.jpg', '采用奔驰E300整车发动机、手自一体变速箱、底盘转向、车轮制动、灯光系统、仪表系统、舒适系统等部件组成。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200319/5622ecfe390cd05cb0b442b0b40b05cb.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/9a/8b4e74ae5703b7e82532c36c99756f.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/92/b275367da72d0ffc0fafd390486479.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/18/cdf496932251b5b67a670985a68182.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/72/c56c2e44b03ca06a010c11de0b23f9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/9f/ad378f40470409a8f0df27140a79d2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/bd/f23cb1e33b4f51c6ed0333fd4bb31f.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e3/aae4cca1c571e0f5cfdd59c2ab8a90.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/84/6be35a6a6e6c1f34252a712dd3c548.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/a7/7da26e9fe3558918350cd031028610.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/d2/fdc106ed16eadaa9763bfec6673f50.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/77/3a2d6ecb6e713623b4a8a2d82e8ea5.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/b4/c8d8e60bd5366174c95873990acb08.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/43/81b225db3478d08c6549e567375efc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/4a/2dacd2834bd5f747573370705301de.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/7a/8458a561bbd2a54bbb92cbd0e98748.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '1', '201', '1584583378');
INSERT INTO `c_laboratory` VALUES ('6', '4', '比亚迪纯电动智慧实训室', '/upload/laboratory/image/44/95f0147410c6622df86913c343f5e4.jpg', '比亚迪EV300纯电动整车改造制作而成, 在保持原车钣金、机械、电器、电池组各个系统相对完整的基础上，对车身覆盖件和车架的关键部位进行合理解剖,展示系统的内部结构。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200316/b3601e4adedf96fac3dc85163d0e0ce7.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/1a/641d55fe73dc78aa94a1b0a041a8cc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/9f/8351ea8101a4f90f415383b9992837.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/7f/52c0f659963612b8ab54544b90b04f.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/24/c81c2f81e1baca183b2ab0d95449d5.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/77/980498d28849b6e238e01e08ad4cde.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6f/a02802ad89f3e5f27d738af5485a4a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/76/249ce9710c4ea8e5a3add870e59340.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/da/05ca332e0543abd383e3b5b0b421cf.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/4f/48cf6e6e810d1a5c5191b8828d0770.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/93/4a30bacadb113ec5a6e04f2a75bfb7.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/66/60bdf5610a79aa5f880e78a49e57dd.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '0', '199', '1584583322');
INSERT INTO `c_laboratory` VALUES ('7', '3', '比亚迪无人驾驶智慧实训室', '/upload/laboratory/image/17/ec2bfacc5f89878b0663cd74bbb427.jpg', '此平台是专门针对高校推出的一款无人驾驶教育平台，基于此平台开发的智能驾驶传感器融合平台，可以实现实验环境下的L3级别的自动驾驶，本平台为全电驱动，主要的针对教育和实验环境，开发人员可通过can接口等通讯方式控制车辆，也可通过安装各种传感器进行自己研发扩展平台的功能，同时控制平台可使用通用PC或者是专用的VCU。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200319/5f9da14efa3fd7d8a462768c371ce98b.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/c7/305bcd3aa77ddd9dd20d35048b12a8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/cc/359c0b52b8a9c73aeb17068d46bb2c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/5e/6f1d62e3064ef6c4c048252a9eb0e2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/4e/1b26af475c63af3bb85cd6ce183712.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/50/1fd47d75ac65d9c6c4cc64db6e6891.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/68/684ee405f4307911caea90903c6d76.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/5d/7414fcbcd9544d00de7736a316de70.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/49/eb7fe30f2b6b272cb3322543f520f6.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/b9/8bb9ed1af0b6d9c3b7fe07ab101e41.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/70/fea53a909b6e8cbf38234ca536cd49.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/d7/9eb8c921408927ec6a348fe9bfd647.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '0', '187', '1584583310');
INSERT INTO `c_laboratory` VALUES ('8', '5', '丰田卡罗拉混动实训室', '/upload/laboratory/image/85/9506281384bb2a064ad6f543be280e.jpg', '设备采用18款卡罗拉混合动力整车改造制作而成, 在保持原车钣金、机械、电器、电池组各个系统相对完整的基础上，对车身覆盖件和车架的关键部位进行合理解剖,展示系统的内部结构。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200317/d9d3c1863eb26a15a3c299dfe591f6d2.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/de/c50eaeb15bd3c7f84dbcfc43495e48.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6e/9646a0dcf97fc61c320ad3956e0d1f.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/d5/c8866dc9b4ab936c895aec89380102.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/28/b2bed389c2c501194f11b6faa74c38.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f2/16d5d50ec96a627257a635e20bb9a5.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/92/b387cd93450ab481c542bfae913778.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/1b/49e4b31285493a762875d1bde9878b.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/43/200369769fa74532c17a265d87ea52.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/ae/95c504fd62ecad9a9d16117f3c48bc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e3/9b7604b27af4daa13c9a362acc9280.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/fd/7c3d016dd5ee5c548e6496d068a3e3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/99/4ab2c6600c28bdbbfe8d8b7e6a5df6.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '0', '187', '1584500220');
INSERT INTO `c_laboratory` VALUES ('9', '5', '广汽传祺混合动力实训室', '/upload/laboratory/image/ec/45cf448ff38071f9fe236d18bf29ab.jpg', '培养具备良好职业素养，掌握广汽汽车技术应用必备的基础理论，专业知识和技能，从事广汽整车及关键部件的生产测试、安装调试、性能测试、质量检验、维护维修以及售后保养工作的高素质技能性专门人才。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200319/074be6b561a0d9236937121e6d2e5926.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/60/9777a04b83be10f2fadcbf702b93af.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f0/a02b87adc18e80a6cc20e65179d4ce.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/45/6b4074e5527f1ec91fec589f1e7afd.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e6/5e2ac2fce666939e30c108f8034be2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/71/bd5a42846272b07f8eea690f0c76b9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/7f/82995a429efee8f9956e93b52da0d5.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/3b/baee3bb9c09cfe8ab18aed720ac378.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/66/452125b28877dd96be4262cacef645.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/e3/d24cd5567c90064007d3cbb1ffe100.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/0c/54e0e7cdee20fc557d38f9c03d72c8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/79/45673a945e4469bf3ceaeca71a157e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/da/a8ad7d2c79049b88123876208061a8.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '0', '187', '1584583283');
INSERT INTO `c_laboratory` VALUES ('10', '4', '吉利帝豪纯电动实训室', '/upload/laboratory/image/28/32c0a0983446f0d9b163e8051642b0.jpg', '设备采用吉利EV450纯电动整车改造制作而成,适合中高等汽车院校与培训机构对学员进行整车教学的需要。外加系统主要包括:检测端子、故障设置系统、故障显示装置等。安卓故障设置系统一套、设备实训指导书一套、云端教学系统一套', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200317/a52eb549f0c6212e249dad7e9249ca1c.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/51/4adc10d956cbbf44cdbbfc11d32f29.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/01/d0e7d2289f143daeca87a951df82b2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6f/92a29c0a3f6e8bb797b13a94da67ee.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/95/05a56dd42245688644267e32a09657.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/20/71bd64dbb40c669c687ea5d9bc28c3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/c1/617534febe9d369f4dcdec4459e987.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/82/90e1c91770ad04794c184d385f2e10.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/3f/7c1bc23cc135786508f219fed8473d.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/41/3cd18a2753be985efa8abb6f6ad83f.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/90/d5b4468b661f14fbaed27abfd26cb3.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/6e/e5ee9c5a1d6ce63d8d79f62f6a9ca5.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '4', '0', '186', '1584583247');
INSERT INTO `c_laboratory` VALUES ('11', '3', '特斯拉无人驾驶实训室', '/upload/laboratory/image/d3/236cc60758c39d82773f2e9460d84b.jpg', '特斯拉无人驾驶辅助系统，是专门针对高校推出的一款无人驾驶教育平台，基于此平台开发的智能驾驶传感器融合平台，可以实现实验环境下的L3级别的自动驾驶，本平台为全电驱动，主要的针对教育和实验环境，开发人员可通过can接口等通讯方式控制车辆，也可通过安装各种传感器进行自己研发扩展平台的功能，同时控制平台可使用通用PC或者是专用的VCU。', '/upload/laboratory/video/20200318/463a734c6bcd17fec63db79fb873f4a1.mp4', '/upload/laboratory/file/20200319/9096e680afc6db0ef5bdac3868683119.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/80/06ecc034ce64d1654e72ae5a35c4e4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/30/a440bfe12c79e305b04d6edb0a7741.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/f6/f7c350c7bc557d0a9a31c8af527151.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/18/174d49f0056622308bab08567ddd63.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/fd/5ce0610129a186e777c9aa6fe42b83.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/dc/7d4388362f7acbdce92cfe7322accc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/7a/cc368ed9a5912bdd0c5734b10a13fc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/9c/e2bb714ef83591f182aaff2a3816de.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/aa/21fc4e2ef9f77ed32326b15ea2e736.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/c4/2ac0b1df9ac328fa4973f8267beb83.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/laboratory/image/0b/40e802370a52b3e72c1023fca39b79.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '3', '0', '186', '1584583233');

-- -----------------------------
-- Table structure for `c_laboratory_category`
-- -----------------------------
DROP TABLE IF EXISTS `c_laboratory_category`;
CREATE TABLE `c_laboratory_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `category_name` varchar(100) DEFAULT '' COMMENT '分类名称',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `c_laboratory_category`
-- -----------------------------
INSERT INTO `c_laboratory_category` VALUES ('3', '无人驾驶', '1584345285');
INSERT INTO `c_laboratory_category` VALUES ('4', '纯电动汽车', '1584500776');
INSERT INTO `c_laboratory_category` VALUES ('5', '混合动力', '1584345349');
INSERT INTO `c_laboratory_category` VALUES ('7', '奔宝奥实训室', '1584350644');

-- -----------------------------
-- Table structure for `c_laboratory_video`
-- -----------------------------
DROP TABLE IF EXISTS `c_laboratory_video`;
CREATE TABLE `c_laboratory_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `la_id` int(11) DEFAULT '0' COMMENT '实验室ID',
  `name` varchar(100) DEFAULT NULL COMMENT '视频名称',
  `video` varchar(150) DEFAULT NULL COMMENT '视频地址',
  `download` varchar(150) DEFAULT NULL COMMENT '下载地址',
  `content` text COMMENT '详情介绍',
  `share_number` int(11) DEFAULT '0' COMMENT '分享次数',
  `fabulous_number` int(11) DEFAULT '0' COMMENT '点赞次数',
  `watch_number` int(11) DEFAULT '0' COMMENT '观看次数',
  `c_time` varchar(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='实验室系列视频表';

-- -----------------------------
-- Records of `c_laboratory_video`
-- -----------------------------
INSERT INTO `c_laboratory_video` VALUES ('1', '2', '整车教具简介', '', '/upload/product/file/20200317/189b43603788b9bcf11ad17a33dd1293.pdf', '&lt;p class=&quot;MsoNormal&quot; align=&quot;left&quot;&gt;&lt;p class=&quot;MsoNormal&quot; align=&quot;left&quot;&gt;&lt;span lang=&quot;EN-US&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;纯电动&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;387&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;马力电动机&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt; &lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;变速箱：电动车单速变速箱&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt; &lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;车身类型：&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;5&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;门&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;5&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;坐掀背车&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt; &lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;长&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;*&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;宽&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;*&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;高：&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;4970*1964*1445&amp;nbsp;&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;轴距：&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;2960&amp;nbsp;&lt;/span&gt;&lt;span lang=&quot;ZH-TW&quot;&gt;最高车速：&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;225&lt;/span&gt;&lt;span&gt;该&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;&lt;a href=&quot;http://www.aiav.com.cn/qcdq/&quot; target=&quot;https://www.dinbon.com/cp/_blank&quot;&gt;&lt;span lang=&quot;EN-US&quot;&gt;汽车外加整车实训台&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;&lt;span&gt;示教板面板上安装有检测端子，采用无损&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;32&lt;/span&gt;&lt;span&gt;针插头链接汽车仪表及仪表传感器与外部灯光系统、发动机系统可直接在面板上检测汽车仪表与外部灯光系统各电路元件的电信号，如电阻、电压、电流、频率信号等。&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;&lt;o:p&gt;&lt;/o:p&gt;&lt;/span&gt;&lt;/p&gt;&lt;/p&gt;&lt;p class=&quot;MsoNormal&quot; align=&quot;left&quot;&gt;&lt;span lang=&quot;EN-US&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &lt;/span&gt;&lt;span&gt;示教板面板部分采用&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;1.5mm&lt;/span&gt;&lt;span&gt;冷板冲压成形结构，外形美观；底架部分采用钢结构焊接，表面采用喷涂工艺处理，带自锁脚轮装置，示教板底座上配有&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;40cm&lt;/span&gt;&lt;span&gt;左右的桌面，方便放置资料、轻型检测仪器等。&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;&lt;o:p&gt;&lt;/o:p&gt;&lt;/span&gt;&lt;/p&gt;&lt;p class=&quot;MsoNormal&quot; align=&quot;left&quot;&gt;&lt;span lang=&quot;EN-US&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &lt;/span&gt;&lt;span&gt;示教板工作采用普通&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;220V&lt;/span&gt;&lt;span&gt;交流电源，经内部电路变压整流转换成&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;12V&lt;/span&gt;&lt;span&gt;直流电源，无需蓄电池，减少充电的麻烦，&lt;/span&gt;&lt;span lang=&quot;EN-US&quot;&gt;12V&lt;/span&gt;&lt;span&gt;直流电源有防短路功能。&lt;img src=&quot;http://cmf.qc110.cn/upload/product/image/52/84e18b2b81862ddd467e552f07d9e9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/span&gt;&lt;/p&gt;&lt;p class=&quot;MsoNormal&quot; align=&quot;left&quot;&gt;&lt;br&gt;&lt;/p&gt;', '0', '0', '0', '1584409602');
INSERT INTO `c_laboratory_video` VALUES ('2', '2', '底盘及电机驱动系统', '', '/upload/product/file/20200317/8f074ea7dff82570a6a348e73b44aa61.pdf', '&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 底盘系统包含前后桥总成，18650高压电池组、交流感应电机、高性能电机控制器、智能触屏系统、电动座椅系统等，学员可通过流水灯流动方向观察过高压上电顺序，18650电池组的串并联结构；了解该车型的高低压互锁系统。&lt;br&gt;&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/product/image/76/fba63d92367e48a801e3e9fc712879.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;&lt;/p&gt;', '0', '0', '0', '1584409805');
INSERT INTO `c_laboratory_video` VALUES ('3', '8', '丰田卡罗拉底盘系统', '/upload/product/video/20200318/4d2980537d0f382f341cce88774c4ecf.mp4', '/upload/product/file/20200318/4573b2ed0691f79575af1d8d52b1f10f.pdf', '&lt;img src=&quot;http://cmf.qc110.cn/upload/product/image/e3/9b7604b27af4daa13c9a362acc9280.jpg&quot; alt=&quot;undefined&quot;&gt;', '0', '0', '0', '1584500337');

-- -----------------------------
-- Table structure for `c_product`
-- -----------------------------
DROP TABLE IF EXISTS `c_product`;
CREATE TABLE `c_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `category_id` int(11) DEFAULT '0' COMMENT '分类ID',
  `product_name` varchar(100) DEFAULT NULL COMMENT '产品名称',
  `image` varchar(100) DEFAULT '' COMMENT '主图地址',
  `images` text COMMENT '产品图片地址',
  `video` varchar(150) DEFAULT NULL COMMENT '视频地址',
  `file` varchar(150) DEFAULT NULL COMMENT '文件地址',
  `content` text COMMENT '详情介绍',
  `share_number` int(11) DEFAULT '0' COMMENT '分享次数',
  `fabulous_number` int(11) DEFAULT '0' COMMENT '点赞次数',
  `c_time` varchar(11) DEFAULT NULL COMMENT '增加时间',
  PRIMARY KEY (`id`),
  KEY `pc_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='产品管理表';

-- -----------------------------
-- Records of `c_product`
-- -----------------------------
INSERT INTO `c_product` VALUES ('1', '1', '特斯拉电池管理系统', '/upload/product/image/42/2ff64011fb3dfc30e71a720129f866.jpg', '/upload/product/images/20200312/52739f10f78e321bdac67e28b2e610d7.jpg', '', '', '&lt;p&gt;&lt;img src=&quot;/upload/product/image/56/2e7152ac495b9be297ab2a58f4c14a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;该系统主要让学员学习特斯拉电池热冷管理智能交互系统的核心技术，管路采用透明装置，方便党员观察动力单元温控系统、电池加热系统、电池冷却系统之间的转换，熟知各系统的循环水泵及转换阀之间的工作原理，该设备安装有流水灯原理展示系统，老师可下载APP通过手机演示热冷管理系统的9种工况。目的让学生了解热冷管理智能交互系统的布置、认知、检测、诊断和维修。&lt;/p&gt;', '0', '0', '1583997679');

-- -----------------------------
-- Table structure for `c_product_category`
-- -----------------------------
DROP TABLE IF EXISTS `c_product_category`;
CREATE TABLE `c_product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据ID',
  `name` varchar(100) DEFAULT NULL COMMENT '产品管理分类名称',
  `c_time` varchar(11) DEFAULT NULL COMMENT '增加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='产品管理分类表';

-- -----------------------------
-- Records of `c_product_category`
-- -----------------------------
INSERT INTO `c_product_category` VALUES ('1', '新能源管理系统', '1583996789');
INSERT INTO `c_product_category` VALUES ('2', '发动机系统', '1583996920');
INSERT INTO `c_product_category` VALUES ('3', '变速箱系统', '1583996931');
INSERT INTO `c_product_category` VALUES ('4', '舒适系统', '1583996889');
INSERT INTO `c_product_category` VALUES ('5', '底盘系统', '1583996906');

-- -----------------------------
-- Table structure for `c_system_annex`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_annex`;
CREATE TABLE `c_system_annex` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联的数据ID',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '类型',
  `group` varchar(100) NOT NULL DEFAULT 'sys' COMMENT '文件分组',
  `file` varchar(255) NOT NULL COMMENT '上传文件',
  `hash` varchar(64) NOT NULL COMMENT '文件hash值',
  `size` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '附件大小KB',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '使用状态(0未使用，1已使用)',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='[系统] 上传附件';


-- -----------------------------
-- Table structure for `c_system_annex_group`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_annex_group`;
CREATE TABLE `c_system_annex_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '附件分组',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `size` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '附件大小kb',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='[系统] 附件分组';


-- -----------------------------
-- Table structure for `c_system_config`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_config`;
CREATE TABLE `c_system_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统配置(1是，0否)',
  `group` varchar(20) NOT NULL DEFAULT 'base' COMMENT '分组',
  `title` varchar(20) NOT NULL COMMENT '配置标题',
  `name` varchar(50) NOT NULL COMMENT '配置名称，由英文字母和下划线组成',
  `value` text NOT NULL COMMENT '配置值',
  `type` varchar(20) NOT NULL DEFAULT 'input' COMMENT '配置类型()',
  `options` text NOT NULL COMMENT '配置项(选项名:选项值)',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件上传接口',
  `tips` varchar(255) NOT NULL COMMENT '配置提示',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL COMMENT '状态',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COMMENT='[系统] 系统配置';

-- -----------------------------
-- Records of `c_system_config`
-- -----------------------------
INSERT INTO `c_system_config` VALUES ('1', '1', 'sys', '扩展配置分组', 'config_group', '', 'array', ' ', '', '请按如下格式填写：&lt;br&gt;键值:键名&lt;br&gt;键值:键名&lt;br&gt;&lt;span style=&quot;color:#f00&quot;&gt;键值只能为英文、数字、下划线&lt;/span&gt;', '2', '1', '1492140215', '1492140215');
INSERT INTO `c_system_config` VALUES ('13', '1', 'base', '网站域名', 'site_domain', '', 'input', '', '', '', '2', '1', '1492140215', '1492140215');
INSERT INTO `c_system_config` VALUES ('14', '1', 'upload', '图片上传大小限制', 'upload_image_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '3', '1', '1490841797', '1491040778');
INSERT INTO `c_system_config` VALUES ('15', '1', 'upload', '允许上传图片格式', 'upload_image_ext', 'jpg,png,gif,jpeg,ico', 'input', '', '', '多个格式请用英文逗号（,）隔开', '4', '1', '1490842130', '1491040778');
INSERT INTO `c_system_config` VALUES ('16', '1', 'upload', '缩略图裁剪方式', 'thumb_type', '2', 'select', '1:等比例缩放
2:缩放后填充
3:居中裁剪
4:左上角裁剪
5:右下角裁剪
6:固定尺寸缩放
', '', '', '5', '1', '1490842450', '1491040778');
INSERT INTO `c_system_config` VALUES ('17', '1', 'upload', '图片水印开关', 'image_watermark', '1', 'switch', '0:关闭
1:开启', '', '', '6', '1', '1490842583', '1491040778');
INSERT INTO `c_system_config` VALUES ('18', '1', 'upload', '图片水印图', 'image_watermark_pic', '', 'image', '', '', '', '7', '1', '1490842679', '1491040778');
INSERT INTO `c_system_config` VALUES ('19', '1', 'upload', '图片水印透明度', 'image_watermark_opacity', '50', 'input', '', '', '可设置值为0~100，数字越小，透明度越高', '8', '1', '1490857704', '1491040778');
INSERT INTO `c_system_config` VALUES ('20', '1', 'upload', '图片水印图位置', 'image_watermark_location', '9', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '9', '1', '1490858228', '1491040778');
INSERT INTO `c_system_config` VALUES ('21', '1', 'upload', '文件上传大小限制', 'upload_file_size', '0', 'input', '', '', '单位：KB，0表示不限制大小', '1', '1', '1490859167', '1491040778');
INSERT INTO `c_system_config` VALUES ('22', '1', 'upload', '允许上传文件格式', 'upload_file_ext', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip', 'input', '', '', '多个格式请用英文逗号（,）隔开', '2', '1', '1490859246', '1491040778');
INSERT INTO `c_system_config` VALUES ('23', '1', 'upload', '文字水印开关', 'text_watermark', '0', 'switch', '0:关闭
1:开启', '', '', '10', '1', '1490860872', '1491040778');
INSERT INTO `c_system_config` VALUES ('24', '1', 'upload', '文字水印内容', 'text_watermark_content', '', 'input', '', '', '', '11', '1', '1490861005', '1491040778');
INSERT INTO `c_system_config` VALUES ('25', '1', 'upload', '文字水印字体', 'text_watermark_font', '', 'file', '', '', '不上传将使用系统默认字体', '12', '1', '1490861117', '1491040778');
INSERT INTO `c_system_config` VALUES ('26', '1', 'upload', '文字水印字体大小', 'text_watermark_size', '20', 'input', '', '', '单位：px(像素)', '13', '1', '1490861204', '1491040778');
INSERT INTO `c_system_config` VALUES ('27', '1', 'upload', '文字水印颜色', 'text_watermark_color', '#000000', 'input', '', '', '文字水印颜色，格式:#000000', '14', '1', '1490861482', '1491040778');
INSERT INTO `c_system_config` VALUES ('28', '1', 'upload', '文字水印位置', 'text_watermark_location', '7', 'select', '7:左下角
1:左上角
4:左居中
9:右下角
3:右上角
6:右居中
2:上居中
8:下居中
5:居中', '', '', '11', '1', '1490861718', '1491040778');
INSERT INTO `c_system_config` VALUES ('29', '1', 'upload', '缩略图尺寸', 'thumb_size', '300x300;500x500', 'input', '', '', '为空则不生成，生成 500x500 的缩略图，则填写 500x500，多个规格填写参考 300x300;500x500;800x800', '4', '1', '1490947834', '1491040778');
INSERT INTO `c_system_config` VALUES ('30', '1', 'sys', '开发模式', 'app_debug', '1', 'switch', '0:关闭
1:开启', '', '&lt;strong class=&quot;red&quot;&gt;生产环境下一定要关闭此配置&lt;/strong&gt;', '3', '1', '1491005004', '1492093874');
INSERT INTO `c_system_config` VALUES ('31', '1', 'sys', '页面Trace', 'app_trace', '0', 'switch', '0:关闭
1:开启', '', '&lt;strong class=&quot;red&quot;&gt;生产环境下一定要关闭此配置&lt;/strong&gt;', '4', '1', '1491005081', '1492093874');
INSERT INTO `c_system_config` VALUES ('33', '1', 'sys', '富文本编辑器', 'editor', 'umeditor', 'select', 'ueditor:UEditor
umeditor:UMEditor
kindeditor:KindEditor
ckeditor:CKEditor', '', '', '0', '1', '1491142648', '1492140215');
INSERT INTO `c_system_config` VALUES ('35', '1', 'databases', '备份目录', 'backup_path', './backup/database/', 'input', '', '', '数据库备份路径,路径必须以 / 结尾', '0', '1', '1491881854', '1491965974');
INSERT INTO `c_system_config` VALUES ('36', '1', 'databases', '备份分卷大小', 'part_size', '20971520', 'input', '', '', '用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '0', '1', '1491881975', '1491965974');
INSERT INTO `c_system_config` VALUES ('37', '1', 'databases', '备份压缩开关', 'compress', '1', 'switch', '0:关闭
1:开启', '', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '0', '1', '1491882038', '1491965974');
INSERT INTO `c_system_config` VALUES ('38', '1', 'databases', '备份压缩级别', 'compress_level', '4', 'radio', '1:最低
4:一般
9:最高', '', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '0', '1', '1491882154', '1491965974');
INSERT INTO `c_system_config` VALUES ('39', '1', 'base', '网站状态', 'site_status', '1', 'switch', '0:关闭
1:开启', '', '站点关闭后将不能访问，后台可正常登录', '1', '1', '1492049460', '1494690024');
INSERT INTO `c_system_config` VALUES ('40', '1', 'sys', '后台管理路径', 'admin_path', 'admin.php', 'input', '', '', '必须以.php为后缀', '1', '1', '1492139196', '1492140215');
INSERT INTO `c_system_config` VALUES ('41', '1', 'base', '网站标题', 'site_title', 'HisiPHP 开源后台管理框架', 'input', '', '', '网站标题是体现一个网站的主旨，要做到主题突出、标题简洁、连贯等特点，建议不超过28个字', '6', '1', '1492502354', '1494695131');
INSERT INTO `c_system_config` VALUES ('42', '1', 'base', '网站关键词', 'site_keywords', 'hisiphp,hisiphp框架,php开源框架', 'input', '', '', '网页内容所包含的核心搜索关键词，多个关键字请用英文逗号&quot;,&quot;分隔', '7', '1', '1494690508', '1494690780');
INSERT INTO `c_system_config` VALUES ('43', '1', 'base', '网站描述', 'site_description', '', 'textarea', '', '', '网页的描述信息，搜索引擎采纳后，作为搜索结果中的页面摘要显示，建议不超过80个字', '8', '1', '1494690669', '1494691075');
INSERT INTO `c_system_config` VALUES ('44', '1', 'base', 'ICP备案信息', 'site_icp', '', 'input', '', '', '请填写ICP备案号，用于展示在网站底部，ICP备案官网：&lt;a href=&quot;http://www.miibeian.gov.cn&quot; target=&quot;_blank&quot;&gt;http://www.miibeian.gov.cn&lt;/a&gt;', '9', '1', '1494691721', '1494692046');
INSERT INTO `c_system_config` VALUES ('45', '1', 'base', '站点统计代码', 'site_statis', '', 'textarea', '', '', '第三方流量统计代码，前台调用时请先用 htmlspecialchars_decode函数转义输出', '10', '1', '1494691959', '1494694797');
INSERT INTO `c_system_config` VALUES ('46', '1', 'base', '网站名称', 'site_name', 'HisiPHP', 'input', '', '', '将显示在浏览器窗口标题等位置', '3', '1', '1494692103', '1494694680');
INSERT INTO `c_system_config` VALUES ('47', '1', 'base', '网站LOGO', 'site_logo', '', 'image', '', '', '网站LOGO图片', '4', '1', '1494692345', '1494693235');
INSERT INTO `c_system_config` VALUES ('48', '1', 'base', '网站图标', 'site_favicon', '', 'image', '', '/system/annex/favicon', '又叫网站收藏夹图标，它显示位于浏览器的地址栏或者标题前面，&lt;strong class=&quot;red&quot;&gt;.ico格式&lt;/strong&gt;，&lt;a href=&quot;https://www.baidu.com/s?ie=UTF-8&amp;wd=favicon&quot; target=&quot;_blank&quot;&gt;点此了解网站图标&lt;/a&gt;', '5', '1', '1494692781', '1494693966');
INSERT INTO `c_system_config` VALUES ('49', '1', 'base', '手机网站', 'wap_site_status', '1', 'switch', '0:关闭
1:开启', '', '如果有手机网站，请设置为开启状态，否则只显示PC网站', '2', '1', '1498405436', '1498405436');
INSERT INTO `c_system_config` VALUES ('50', '1', 'sys', '云端推送', 'cloud_push', '0', 'switch', '0:关闭
1:开启', '', '关闭之后，无法通过云端推送安装扩展', '5', '1', '1504250320', '1504250320');
INSERT INTO `c_system_config` VALUES ('51', '1', 'base', '手机网站域名', 'wap_domain', '', 'input', '', '', '手机访问将自动跳转至此域名', '2', '1', '1504304776', '1504304837');
INSERT INTO `c_system_config` VALUES ('52', '1', 'sys', '多语言支持', 'multi_language', '0', 'switch', '0:关闭
1:开启', '', '开启后你可以自由上传多种语言包', '6', '1', '1506532211', '1506532211');
INSERT INTO `c_system_config` VALUES ('53', '1', 'sys', '后台白名单验证', 'admin_whitelist_verify', '0', 'switch', '0:禁用
1:启用', '', '禁用后不存在的菜单节点将不在提示', '7', '1', '1542012232', '1542012321');
INSERT INTO `c_system_config` VALUES ('54', '1', 'sys', '系统日志保留', 'system_log_retention', '30', 'input', '', '', '单位天，系统将自动清除 ? 天前的系统日志', '8', '1', '1542013958', '1542014158');
INSERT INTO `c_system_config` VALUES ('55', '1', 'upload', '上传驱动', 'upload_driver', 'local', 'select', 'local:本地上传', '', '资源上传驱动设置', '0', '1', '1558599270', '1558618703');

-- -----------------------------
-- Table structure for `c_system_hook`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_hook`;
CREATE TABLE `c_system_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统插件',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `source` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子来源[plugins.插件名，module.模块名]',
  `intro` varchar(200) NOT NULL DEFAULT '' COMMENT '钩子简介',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子表';

-- -----------------------------
-- Records of `c_system_hook`
-- -----------------------------
INSERT INTO `c_system_hook` VALUES ('1', '1', 'system_admin_index', '', '后台首页', '1', '1490885108', '1490885108');
INSERT INTO `c_system_hook` VALUES ('2', '1', 'system_admin_tips', '', '后台所有页面提示', '1', '1490713165', '1490885137');
INSERT INTO `c_system_hook` VALUES ('3', '1', 'system_annex_upload', '', '附件上传钩子，可扩展上传到第三方存储', '1', '1490884242', '1490885121');
INSERT INTO `c_system_hook` VALUES ('4', '1', 'system_member_login', '', '会员登陆成功之后的动作', '1', '1490885108', '1490885108');
INSERT INTO `c_system_hook` VALUES ('5', '1', 'system_member_register', '', '会员注册成功后的动作', '1', '1512610518', '1512610518');

-- -----------------------------
-- Table structure for `c_system_hook_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_hook_plugins`;
CREATE TABLE `c_system_hook_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL COMMENT '钩子id',
  `plugins` varchar(32) NOT NULL COMMENT '插件标识',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 钩子-插件对应表';

-- -----------------------------
-- Records of `c_system_hook_plugins`
-- -----------------------------
INSERT INTO `c_system_hook_plugins` VALUES ('1', 'system_admin_index', 'hisiphp', '1509380301', '1509380301', '0', '1');

-- -----------------------------
-- Table structure for `c_system_language`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_language`;
CREATE TABLE `c_system_language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '语言包名称',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '编码',
  `locale` varchar(255) NOT NULL DEFAULT '' COMMENT '本地浏览器语言编码',
  `icon` varchar(30) NOT NULL DEFAULT '' COMMENT '图标',
  `pack` varchar(100) NOT NULL DEFAULT '' COMMENT '上传的语言包',
  `sort` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='[系统] 语言包';

-- -----------------------------
-- Records of `c_system_language`
-- -----------------------------
INSERT INTO `c_system_language` VALUES ('1', '简体中文', 'zh-cn', 'zh-CN,zh-CN.UTF-8,zh-cn', '', '1', '1', '1');

-- -----------------------------
-- Table structure for `c_system_log`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_log`;
CREATE TABLE `c_system_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT '',
  `url` varchar(200) DEFAULT '',
  `param` text,
  `remark` varchar(255) DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(128) DEFAULT '',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8 COMMENT='[系统] 操作日志';

-- -----------------------------
-- Records of `c_system_log`
-- -----------------------------
INSERT INTO `c_system_log` VALUES ('1', '1', '后台首页', '/admin.php/system/index/index.html', '[]', '浏览数据', '34', '27.188.252.74', '1583230497', '1584585970');
INSERT INTO `c_system_log` VALUES ('2', '1', '本地模块', '/admin.php/system/module/index.html', '[]', '浏览数据', '4', '27.188.252.74', '1583230502', '1584087269');
INSERT INTO `c_system_log` VALUES ('3', '1', '生成模块', '/admin.php/system/module/design.html', '[]', '浏览数据', '2', '127.0.0.1', '1583230504', '1583230555');
INSERT INTO `c_system_log` VALUES ('4', '1', '生成模块', '/admin.php/system/module/design.html', '{\"name\":\"admin\",\"title\":\"\\u540e\\u53f0\\u7ba1\\u7406\",\"identifier\":\"admin\",\"intro\":\"\\u540e\\u53f0\\u6240\\u6709\\u7ba1\\u7406\",\"author\":\"Peng\",\"url\":\"\",\"version\":\"1.0.0\",\"file\":\"common.php\",\"dir\":\"admin\\r\\nhome\\r\\nconfig\\r\\nmodel\\r\\nlang\\r\\nsql\\r\\nvalidate\\r\\nview\"}', '保存数据', '1', '127.0.0.1', '1583230533', '1583230533');
INSERT INTO `c_system_log` VALUES ('5', '1', '本地模块', '/admin.php/system/module/index/status/0.html', '{\"status\":\"0\"}', '浏览数据', '2', '127.0.0.1', '1583230536', '1583230554');
INSERT INTO `c_system_log` VALUES ('6', '1', '安装模块', '/admin.php/system/module/install/id/4.html', '{\"id\":\"4\"}', '浏览数据', '1', '127.0.0.1', '1583230539', '1583230539');
INSERT INTO `c_system_log` VALUES ('7', '1', '安装模块', '/admin.php/system/module/install.html', '{\"clear\":\"1\",\"demo_data\":\"1\",\"id\":\"4\"}', '保存数据', '1', '127.0.0.1', '1583230546', '1583230546');
INSERT INTO `c_system_log` VALUES ('8', '1', '本地模块', '/admin.php/system/module/index/status/2.html', '{\"status\":\"2\"}', '浏览数据', '1', '127.0.0.1', '1583230549', '1583230549');
INSERT INTO `c_system_log` VALUES ('9', '1', '本地模块', '/admin.php/system/module/index/status/1.html', '{\"status\":\"1\"}', '浏览数据', '1', '127.0.0.1', '1583230553', '1583230553');
INSERT INTO `c_system_log` VALUES ('10', '1', '导入模块', '/admin.php/system/module/import.html', '[]', '浏览数据', '1', '127.0.0.1', '1583230554', '1583230554');
INSERT INTO `c_system_log` VALUES ('11', '1', '系统菜单', '/admin.php/system/menu/index.html', '[]', '浏览数据', '54', '27.188.252.74', '1583230561', '1584436258');
INSERT INTO `c_system_log` VALUES ('12', '1', '排序设置', '/admin.php/system/menu/sort/table/admin_menu/id/2.html', '{\"val\":\"2\",\"table\":\"admin_menu\",\"id\":\"2\"}', '保存数据', '1', '127.0.0.1', '1583230574', '1583230574');
INSERT INTO `c_system_log` VALUES ('13', '1', '排序设置', '/admin.php/system/menu/sort/table/admin_menu/id/3.html', '{\"val\":\"3\",\"table\":\"admin_menu\",\"id\":\"3\"}', '保存数据', '1', '127.0.0.1', '1583230575', '1583230575');
INSERT INTO `c_system_log` VALUES ('14', '1', '排序设置', '/admin.php/system/menu/sort/table/admin_menu/id/141.html', '{\"val\":\"1\",\"table\":\"admin_menu\",\"id\":\"141\"}', '保存数据', '1', '127.0.0.1', '1583230577', '1583230577');
INSERT INTO `c_system_log` VALUES ('15', '1', '添加菜单', '/admin.php/system/menu/add/pid/141/mod/admin.html', '{\"pid\":\"141\",\"mod\":\"admin\"}', '浏览数据', '3', '27.188.252.74', '1583230787', '1583824722');
INSERT INTO `c_system_log` VALUES ('16', '1', '添加菜单', '/admin.php/system/menu/add.html', '{\"pid\":\"152\",\"title\":\"\\u8bbe\\u7f6e\\u4e3b\\u63a8\\u89c6\\u9891\",\"icon\":\"aicon ai-tishi\",\"url\":\"admin\\/video\\/main\",\"param\":\"\",\"status\":\"1\",\"system\":\"0\",\"nav\":\"1\",\"id\":\"\",\"module\":\"admin\"}', '保存数据', '11', '27.188.252.74', '1583230825', '1583981523');
INSERT INTO `c_system_log` VALUES ('17', '1', '添加菜单', '/admin.php/system/menu/add/pid/142/mod/admin.html', '{\"pid\":\"142\",\"mod\":\"admin\"}', '浏览数据', '5', '127.0.0.1', '1583230832', '1583478628');
INSERT INTO `c_system_log` VALUES ('18', '1', '轮播广告', '/admin.php/admin/banner/index.html', '[]', '浏览数据', '83', '27.188.252.74', '1583231148', '1584417178');
INSERT INTO `c_system_log` VALUES ('19', '1', '设置主题', '/admin.php/system/user/settheme.html?theme=3', '{\"theme\":\"3\"}', '浏览数据', '1', '127.0.0.1', '1583285290', '1583285290');
INSERT INTO `c_system_log` VALUES ('20', '1', '轮播广告', '/admin.php/admin/banner/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '66', '27.188.252.74', '1583285699', '1584417179');
INSERT INTO `c_system_log` VALUES ('21', '1', '未加入系统菜单', '/admin.php/admin/banner/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '37', '27.188.252.74', '1583285914', '1584070442');
INSERT INTO `c_system_log` VALUES ('22', '1', '未加入系统菜单', '/admin.php/admin/banner/add.html', '[]', '浏览数据', '1', '127.0.0.1', '1583285971', '1583285971');
INSERT INTO `c_system_log` VALUES ('23', '1', '配置管理', '/admin.php/system/config/index.html', '[]', '浏览数据', '4', '27.188.252.74', '1583286087', '1584436192');
INSERT INTO `c_system_log` VALUES ('24', '1', '配置管理', '/admin.php/system/config/index.html?page=1&limit=20', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '4', '27.188.252.74', '1583286088', '1584436192');
INSERT INTO `c_system_log` VALUES ('25', '1', '系统设置', '/admin.php/system/system/index.html', '[]', '浏览数据', '3', '27.188.252.74', '1583286089', '1584436189');
INSERT INTO `c_system_log` VALUES ('26', '1', '系统管理员', '/admin.php/system/user/index.html', '[]', '浏览数据', '7', '27.188.252.74', '1583286092', '1584586577');
INSERT INTO `c_system_log` VALUES ('27', '1', '系统管理员', '/admin.php/system/user/index.html?page=1&limit=20', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '7', '27.188.252.74', '1583286093', '1584586577');
INSERT INTO `c_system_log` VALUES ('28', '1', '数据库管理', '/admin.php/system/database/index.html', '[]', '浏览数据', '5', '27.188.252.74', '1583286093', '1584586675');
INSERT INTO `c_system_log` VALUES ('29', '1', '数据库管理', '/admin.php/system/database/index.html?group=export&page=1&limit=10', '{\"group\":\"export\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '6', '27.188.252.74', '1583286094', '1584586675');
INSERT INTO `c_system_log` VALUES ('30', '1', '系统日志', '/admin.php/system/log/index.html', '[]', '浏览数据', '2', '27.188.252.74', '1583286094', '1584087258');
INSERT INTO `c_system_log` VALUES ('31', '1', '系统日志', '/admin.php/system/log/index.html?page=1&limit=20', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '2', '27.188.252.74', '1583286095', '1584087258');
INSERT INTO `c_system_log` VALUES ('32', '1', '应用市场', '/admin.php/system/store/index.html', '[]', '浏览数据', '3', '27.188.252.74', '1583286097', '1584351802');
INSERT INTO `c_system_log` VALUES ('33', '1', '添加菜单', '/admin.php/system/menu/add/pid/1/mod/system.html', '{\"pid\":\"1\",\"mod\":\"system\"}', '浏览数据', '1', '127.0.0.1', '1583286108', '1583286108');
INSERT INTO `c_system_log` VALUES ('34', '1', '轮播广告', '/admin.php/admin/banner/index.html?page=1&limit=20', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '9', '127.0.0.1', '1583288057', '1583288792');
INSERT INTO `c_system_log` VALUES ('35', '1', '未加入系统菜单', '/admin.php/admin', '[]', '浏览数据', '1', '127.0.0.1', '1583288681', '1583288681');
INSERT INTO `c_system_log` VALUES ('36', '1', '附件上传', '/admin.php/system/annex/upload/group/supplier/thumb/100x100/water/no.html', '{\"group\":\"supplier\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '3', '127.0.0.1', '1583289477', '1583289527');
INSERT INTO `c_system_log` VALUES ('37', '1', '未加入系统菜单', '/admin.php/admin/banner/add.html', '{\"type\":\"2\",\"data_id\":\"2\",\"image\":\"\\/upload\\/banner\\/image\\/ef\\/a658af4d6104ea76c365561ff92906.jpg\"}', '保存数据', '7', '27.188.252.74', '1583289479', '1583986336');
INSERT INTO `c_system_log` VALUES ('38', '1', '附件上传', '/admin.php/system/annex/upload/group/banner/thumb/100x100/water/no.html', '{\"group\":\"banner\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '5', '27.188.252.74', '1583289594', '1583986335');
INSERT INTO `c_system_log` VALUES ('39', '1', '未加入系统菜单', '/admin.php/admin/banner/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '7', '27.188.252.74', '1583289966', '1584417169');
INSERT INTO `c_system_log` VALUES ('40', '1', '未加入系统菜单', '/admin.php/admin/banner/edit.html', '{\"id\":\"1\",\"type\":\"2\",\"data_id\":\"2\",\"image\":\"\\/upload\\/banner\\/image\\/62\\/aaaba56b3e4b5f3f656f68bb1fd2d7.jpg\"}', '保存数据', '6', '27.188.252.74', '1583290228', '1584417175');
INSERT INTO `c_system_log` VALUES ('41', '1', '未加入系统菜单', '/admin.php/admin/banner/edit.html?id=4&hisi_iframe=yes', '{\"id\":\"4\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1583290260', '1583825976');
INSERT INTO `c_system_log` VALUES ('42', '1', '未加入系统菜单', '/admin.php/admin/banner/del.html?id=3', '{\"id\":\"3\"}', '浏览数据', '1', '127.0.0.1', '1583292178', '1583292178');
INSERT INTO `c_system_log` VALUES ('43', '1', '产品分类', '/admin.php/admin/category/index.html', '[]', '浏览数据', '36', '27.188.252.74', '1583292656', '1584070589');
INSERT INTO `c_system_log` VALUES ('44', '1', '产品分类', '/admin.php/admin/category/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '35', '27.188.252.74', '1583292774', '1584070590');
INSERT INTO `c_system_log` VALUES ('45', '1', '未加入系统菜单', '/admin.php/admin/category/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '10', '27.188.252.74', '1583292932', '1583996902');
INSERT INTO `c_system_log` VALUES ('46', '1', '未加入系统菜单', '/admin.php/admin/category/add.html', '{\"name\":\"\\u5e95\\u76d8\\u7cfb\\u7edf\"}', '保存数据', '8', '27.188.252.74', '1583293048', '1583996906');
INSERT INTO `c_system_log` VALUES ('47', '1', '未加入系统菜单', '/admin.php/admin/category/edit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1583293062', '1583996916');
INSERT INTO `c_system_log` VALUES ('48', '1', '未加入系统菜单', '/admin.php/admin/category/edit.html', '{\"name\":\"\\u53d8\\u901f\\u7bb1\\u7cfb\\u7edf\",\"id\":\"3\"}', '保存数据', '3', '27.188.252.74', '1583293064', '1583996931');
INSERT INTO `c_system_log` VALUES ('49', '1', '未加入系统菜单', '/admin.php/admin/category/del.html?id=2', '{\"id\":\"2\"}', '浏览数据', '1', '127.0.0.1', '1583293722', '1583293722');
INSERT INTO `c_system_log` VALUES ('50', '1', '全部产品', '/admin.php/admin/product/index.html', '[]', '浏览数据', '62', '27.188.252.74', '1583305634', '1584347414');
INSERT INTO `c_system_log` VALUES ('51', '1', '全部产品', '/admin.php/admin/product/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '62', '27.188.252.74', '1583305635', '1584347414');
INSERT INTO `c_system_log` VALUES ('52', '1', '未加入系统菜单', '/admin.php/admin/product/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '26', '27.188.252.74', '1583309201', '1584070592');
INSERT INTO `c_system_log` VALUES ('53', '1', '附件上传', '/admin.php/system/annex/upload/group/product/thumb/100x100/water/no.html', '{\"group\":\"product\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '16', '27.188.252.74', '1583310376', '1583997418');
INSERT INTO `c_system_log` VALUES ('54', '1', '未加入系统菜单', '/admin.php/admin/product/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '保存数据', '1', '127.0.0.1', '1583316129', '1583316129');
INSERT INTO `c_system_log` VALUES ('55', '1', '未加入系统菜单', '/admin.php/admin/product/add.html', '[]', '浏览数据', '58', '127.0.0.1', '1583316227', '1583397486');
INSERT INTO `c_system_log` VALUES ('56', '1', '未加入系统菜单', '/admin.php/admin/product/add.html', '{\"category_id\":\"1\",\"product_name\":\"\\u7279\\u65af\\u62c9\\u7535\\u6c60\\u7ba1\\u7406\\u7cfb\\u7edf\",\"image\":\"\\/upload\\/product\\/image\\/42\\/2ff64011fb3dfc30e71a720129f866.jpg\",\"video\":\"\",\"images\":\"\\/upload\\/product\\/images\\/20200312\\/52739f10f78e321bdac67e28b2e610d7.jpg\",\"file\":\"\",\"content\":\"&lt;p&gt;&lt;img src=&quot;\\/upload\\/product\\/image\\/56\\/2e7152ac495b9be297ab2a58f4c14a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;br&gt;&lt;\\/p&gt;&lt;p&gt;\\u8be5\\u7cfb\\u7edf\\u4e3b\\u8981\\u8ba9\\u5b66\\u5458\\u5b66\\u4e60\\u7279\\u65af\\u62c9\\u7535\\u6c60\\u70ed\\u51b7\\u7ba1\\u7406\\u667a\\u80fd\\u4ea4\\u4e92\\u7cfb\\u7edf\\u7684\\u6838\\u5fc3\\u6280\\u672f\\uff0c\\u7ba1\\u8def\\u91c7\\u7528\\u900f\\u660e\\u88c5\\u7f6e\\uff0c\\u65b9\\u4fbf\\u515a\\u5458\\u89c2\\u5bdf\\u52a8\\u529b\\u5355\\u5143\\u6e29\\u63a7\\u7cfb\\u7edf\\u3001\\u7535\\u6c60\\u52a0\\u70ed\\u7cfb\\u7edf\\u3001\\u7535\\u6c60\\u51b7\\u5374\\u7cfb\\u7edf\\u4e4b\\u95f4\\u7684\\u8f6c\\u6362\\uff0c\\u719f\\u77e5\\u5404\\u7cfb\\u7edf\\u7684\\u5faa\\u73af\\u6c34\\u6cf5\\u53ca\\u8f6c\\u6362\\u9600\\u4e4b\\u95f4\\u7684\\u5de5\\u4f5c\\u539f\\u7406\\uff0c\\u8be5\\u8bbe\\u5907\\u5b89\\u88c5\\u6709\\u6d41\\u6c34\\u706f\\u539f\\u7406\\u5c55\\u793a\\u7cfb\\u7edf\\uff0c\\u8001\\u5e08\\u53ef\\u4e0b\\u8f7dAPP\\u901a\\u8fc7\\u624b\\u673a\\u6f14\\u793a\\u70ed\\u51b7\\u7ba1\\u7406\\u7cfb\\u7edf\\u76849\\u79cd\\u5de5\\u51b5\\u3002\\u76ee\\u7684\\u8ba9\\u5b66\\u751f\\u4e86\\u89e3\\u70ed\\u51b7\\u7ba1\\u7406\\u667a\\u80fd\\u4ea4\\u4e92\\u7cfb\\u7edf\\u7684\\u5e03\\u7f6e\\u3001\\u8ba4\\u77e5\\u3001\\u68c0\\u6d4b\\u3001\\u8bca\\u65ad\\u548c\\u7ef4\\u4fee\\u3002&lt;\\/p&gt;\"}', '保存数据', '12', '27.188.252.74', '1583316251', '1583997679');
INSERT INTO `c_system_log` VALUES ('57', '1', '未加入系统菜单', '/admin.php/admin/product/upload/group/product/thumb/100x100/water/no.html', '{\"group\":\"product\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '5', '127.0.0.1', '1583318052', '1583318457');
INSERT INTO `c_system_log` VALUES ('58', '1', '未加入系统菜单', '/admin.php/admin/product/upload/group/product/thumb/200/water/no.html', '{\"group\":\"product\",\"thumb\":\"200\",\"water\":\"no\"}', '保存数据', '10', '27.188.252.74', '1583373434', '1583997672');
INSERT INTO `c_system_log` VALUES ('59', '1', '未加入系统菜单', '/admin.php/admin/product/upload_file.html', '[]', '保存数据', '4', '127.0.0.1', '1583374920', '1583375360');
INSERT INTO `c_system_log` VALUES ('60', '1', '未加入系统菜单', '/admin.php/admin/product/upload_file/type/video.html', '{\"type\":\"video\"}', '保存数据', '8', '127.0.0.1', '1583375558', '1583398544');
INSERT INTO `c_system_log` VALUES ('61', '1', '未加入系统菜单', '/admin.php/admin/product/upload_file/type/images.html', '{\"type\":\"images\"}', '保存数据', '17', '27.188.252.74', '1583375854', '1583997486');
INSERT INTO `c_system_log` VALUES ('62', '1', '未加入系统菜单', '/admin.php/admin/product/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '12', '27.188.252.74', '1583398293', '1584347416');
INSERT INTO `c_system_log` VALUES ('63', '1', '未加入系统菜单', '/admin.php/admin/product/edit.html', '{\"category_id\":\"1\",\"product_name\":\"\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u540d\\u79f0111\",\"id\":\"1\",\"image\":\"\\/upload\\/product\\/image\\/88\\/ddb189f72fb538b423e84c93bfa751.jpg\",\"video\":\"\\/upload\\/product\\/video\\/20200305\\/50e217aedaacf8c985bae876f1e69fdf.mp4\",\"images\":\"\\/upload\\/product\\/images\\/20200305\\/02c3e94cd6e4c3dfc1745917da9d55a8.jpg,\\/upload\\/product\\/images\\/20200305\\/a25335538343c8f04493787a130843ca.jpg\",\"file\":\"\\/upload\\/product\\/video\\/20200305\\/373052ad4b63725c2a66b386219b23a5.pdf\",\"content\":\"&lt;p&gt;\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185&lt;b&gt;\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1&lt;\\/b&gt;\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1&lt;i&gt;\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9&lt;\\/i&gt;\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5&lt;u&gt;\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7&lt;\\/u&gt;\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9\\u6d4b\\u8bd5\\u4ea7\\u54c1\\u5185\\u5bb9&lt;\\/p&gt;&lt;p&gt;&lt;img src=&quot;\\/upload\\/product\\/image\\/0f\\/a01be9829d5515d9a84d7ce7a71e3b.png&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;\"}', '保存数据', '1', '127.0.0.1', '1583398549', '1583398549');
INSERT INTO `c_system_log` VALUES ('64', '1', '实训室列表', '/admin.php/admin/laboratory/index.html', '[]', '浏览数据', '166', '27.188.252.74', '1583399338', '1584583408');
INSERT INTO `c_system_log` VALUES ('65', '1', '实训室列表', '/admin.php/admin/laboratory/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '165', '27.188.252.74', '1583399338', '1584583409');
INSERT INTO `c_system_log` VALUES ('66', '1', '未加入系统菜单', '/admin.php/admin/laboratory/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '51', '27.188.252.74', '1583399469', '1584411705');
INSERT INTO `c_system_log` VALUES ('67', '1', '未加入系统菜单', '/admin.php/admin/laboratory/upload_file/type/video.html', '{\"type\":\"video\"}', '保存数据', '13', '27.188.252.74', '1583399827', '1584500218');
INSERT INTO `c_system_log` VALUES ('68', '1', '未加入系统菜单', '/admin.php/admin/laboratory/upload_file/type/file.html', '{\"type\":\"file\"}', '保存数据', '28', '27.188.252.74', '1583399832', '1584583377');
INSERT INTO `c_system_log` VALUES ('69', '1', '未加入系统菜单', '/admin.php/admin/laboratory/upload/group/laboratory/thumb/200/water/no.html', '{\"group\":\"laboratory\",\"thumb\":\"200\",\"water\":\"no\"}', '保存数据', '194', '27.188.252.74', '1583399856', '1584411826');
INSERT INTO `c_system_log` VALUES ('70', '1', '未加入系统菜单', '/admin.php/admin/laboratory/add.html', '{\"category_id\":\"3\",\"laboratory_name\":\"\\u7279\\u65af\\u62c9\\u65e0\\u4eba\\u9a7e\\u9a76\\u5b9e\\u8bad\\u5ba4\",\"image\":\"\\/upload\\/laboratory\\/image\\/d3\\/236cc60758c39d82773f2e9460d84b.jpg\",\"introduction\":\"\\u7279\\u65af\\u62c9\\u65e0\\u4eba\\u9a7e\\u9a76\\u8f85\\u52a9\\u7cfb\\u7edf\\uff0c\\u662f\\u4e13\\u95e8\\u9488\\u5bf9\\u9ad8\\u6821\\u63a8\\u51fa\\u7684\\u4e00\\u6b3e\\u65e0\\u4eba\\u9a7e\\u9a76\\u6559\\u80b2\\u5e73\\u53f0\\uff0c\\u57fa\\u4e8e\\u6b64\\u5e73\\u53f0\\u5f00\\u53d1\\u7684\\u667a\\u80fd\\u9a7e\\u9a76\\u4f20\\u611f\\u5668\\u878d\\u5408\\u5e73\\u53f0\\uff0c\\u53ef\\u4ee5\\u5b9e\\u73b0\\u5b9e\\u9a8c\\u73af\\u5883\\u4e0b\\u7684L3\\u7ea7\\u522b\\u7684\\u81ea\\u52a8\\u9a7e\\u9a76\\uff0c\\u672c\\u5e73\\u53f0\\u4e3a\\u5168\\u7535\\u9a71\\u52a8\\uff0c\\u4e3b\\u8981\\u7684\\u9488\\u5bf9\\u6559\\u80b2\\u548c\\u5b9e\\u9a8c\\u73af\\u5883\\uff0c\\u5f00\\u53d1\\u4eba\\u5458\\u53ef\\u901a\\u8fc7can\\u63a5\\u53e3\\u7b49\\u901a\\u8baf\\u65b9\\u5f0f\\u63a7\\u5236\\u8f66\\u8f86\\uff0c\\u4e5f\\u53ef\\u901a\\u8fc7\\u5b89\\u88c5\\u5404\\u79cd\\u4f20\\u611f\\u5668\\u8fdb\\u884c\\u81ea\\u5df1\\u7814\\u53d1\\u6269\\u5c55\\u5e73\\u53f0\\u7684\\u529f\\u80fd\\uff0c\\u540c\\u65f6\\u63a7\\u5236\\u5e73\\u53f0\\u53ef\\u4f7f\\u7528\\u901a\\u7528PC\\u6216\\u8005\\u662f\\u4e13\\u7528\\u7684VCU\\u3002\",\"video\":\"\",\"file\":\"\\/upload\\/laboratory\\/file\\/20200317\\/c4e54944c27ab07b09928fdef6cc40b4.pdf\",\"content\":\"&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/80\\/06ecc034ce64d1654e72ae5a35c4e4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/30\\/a440bfe12c79e305b04d6edb0a7741.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/f6\\/f7c350c7bc557d0a9a31c8af527151.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/18\\/174d49f0056622308bab08567ddd63.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/fd\\/5ce0610129a186e777c9aa6fe42b83.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/dc\\/7d4388362f7acbdce92cfe7322accc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/7a\\/cc368ed9a5912bdd0c5734b10a13fc.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/9c\\/e2bb714ef83591f182aaff2a3816de.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/aa\\/21fc4e2ef9f77ed32326b15ea2e736.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/c4\\/2ac0b1df9ac328fa4973f8267beb83.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/0b\\/40e802370a52b3e72c1023fca39b79.jpg&quot; alt=&quot;undefined&quot;&gt;\"}', '保存数据', '18', '27.188.252.74', '1583399945', '1584411829');
INSERT INTO `c_system_log` VALUES ('71', '1', '附件上传', '/admin.php/system/annex/upload/group/laboratory/thumb/100x100/water/no.html', '{\"group\":\"laboratory\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '20', '27.188.252.74', '1583402721', '1584411724');
INSERT INTO `c_system_log` VALUES ('72', '1', '未加入系统菜单', '/admin.php/admin/laboratory/add.html', '[]', '浏览数据', '4', '127.0.0.1', '1583464404', '1583464540');
INSERT INTO `c_system_log` VALUES ('73', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '24', '27.188.252.74', '1583464800', '1584583400');
INSERT INTO `c_system_log` VALUES ('74', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html', '{\"category_id\":\"7\",\"laboratory_name\":\"\\u5965\\u8fea\\u667a\\u6167\\u5b9e\\u8bad\\u5ba4\",\"id\":\"1\",\"image\":\"\\/upload\\/laboratory\\/image\\/ae\\/f9074e441f6ba1b18f2fc6eee9f5e0.jpg\",\"introduction\":\"\\u4ee5\\u5965\\u8feaA6L\\u53d1\\u52a8\\u673a\\u5b9e\\u7269\\u4e3a\\u57fa\\u7840\\uff0c\\u7531\\u4e3b\\u53f0\\u67b6\\u3001\\u63a7\\u5236\\u68c0\\u6d4b\\u9762\\u677f\\u4e24\\u90e8\\u5206\\u7ec4\\u6210\\u3002\\u9002\\u7528\\u4e8e\\u6c7d\\u6cb9\\u53d1\\u52a8\\u673a\\u6784\\u9020\\u4e0e\\u7ef4\\u4fee\\u5b9e\\u8bad\\u6559\\u5b66\\uff0c\\u80fd\\u591f\\u6ee1\\u8db3\\u5bf9\\u6c7d\\u6cb9\\u53d1\\u52a8\\u673a\\u7684\\u7ed3\\u6784\\u3001\\u5de5\\u4f5c\\u539f\\u7406\\u3001\\u6545\\u969c\\u8bbe\\u7f6e\\u53ca\\u8bca\\u65ad\\u7684\\u6559\\u5b66\\u9700\\u8981\\u3002\",\"video\":\"\\/upload\\/laboratory\\/video\\/20200318\\/463a734c6bcd17fec63db79fb873f4a1.mp4\",\"file\":\"\\/upload\\/laboratory\\/file\\/20200316\\/58b8899030ba271f3b5bd93a98a2ba89.pdf\",\"content\":\"&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/26\\/1641fb549d3b3197a9fde99cfcfaa2.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/97\\/d4f00ca4e975c9da04a0c02e1e17f0.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/0b\\/6656acb9dd2f4ecd3f885eb988cd01.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/6a\\/c975f6a85edb906029fdcc43b91744.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/58\\/b898518f0bfad396d8889c76f3d55c.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/e4\\/f363af86f1dbd74e1e03b2bcdc529e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/79\\/b157423c023a82bf175b7419cd9cc0.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/29\\/abba6d6f60a8a584f02a7fc855de03.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/d8\\/76a9e758847eb20226a40d0cddbd92.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/04\\/01cab4edd46ecdabcc56b2d89ff337.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/e3\\/19ca98b92822775bdacbf10c2629b4.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/6f\\/8b3d6fae61cbea723124cdd9181aa9.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/a1\\/4c26843371fd728c89e41e01ee1545.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/81\\/f95b3b13113ab6f0e186a7fd0624d8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/laboratory\\/image\\/90\\/5b85c1b03923b2191e4c4a71d993e2.jpg&quot; alt=&quot;undefined&quot;&gt;\"}', '保存数据', '36', '27.188.252.74', '1583466866', '1584583405');
INSERT INTO `c_system_log` VALUES ('75', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/index.html', '[]', '浏览数据', '25', '127.0.0.1', '1583478696', '1583479043');
INSERT INTO `c_system_log` VALUES ('76', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '24', '127.0.0.1', '1583478697', '1583479044');
INSERT INTO `c_system_log` VALUES ('77', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '11', '27.188.252.74', '1583478698', '1584500229');
INSERT INTO `c_system_log` VALUES ('78', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/upload_file/type/video.html', '{\"type\":\"video\"}', '保存数据', '2', '27.188.252.74', '1583478793', '1584500273');
INSERT INTO `c_system_log` VALUES ('79', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/upload_file/type/file.html', '{\"type\":\"file\"}', '保存数据', '4', '27.188.252.74', '1583478797', '1584500301');
INSERT INTO `c_system_log` VALUES ('80', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/add.html', '{\"la_id\":\"8\",\"name\":\"\\u4e30\\u7530\\u5361\\u7f57\\u62c9\\u5e95\\u76d8\\u7cfb\\u7edf\",\"video\":\"\\/upload\\/product\\/video\\/20200318\\/4d2980537d0f382f341cce88774c4ecf.mp4\",\"download\":\"\\/upload\\/product\\/file\\/20200318\\/4573b2ed0691f79575af1d8d52b1f10f.pdf\",\"content\":\"&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/product\\/image\\/e3\\/9b7604b27af4daa13c9a362acc9280.jpg&quot; alt=&quot;undefined&quot;&gt;\"}', '保存数据', '4', '27.188.252.74', '1583478800', '1584500337');
INSERT INTO `c_system_log` VALUES ('81', '1', '添加快捷菜单', '/admin.php/system/menu/quick/id/0.html', '{\"id\":\"0\"}', '浏览数据', '1', '127.0.0.1', '1583478889', '1583478889');
INSERT INTO `c_system_log` VALUES ('82', '1', '修改菜单', '/admin.php/system/menu/edit/id/147/mod/admin.html', '{\"id\":\"147\",\"mod\":\"admin\"}', '浏览数据', '2', '127.0.0.1', '1583478969', '1583479053');
INSERT INTO `c_system_log` VALUES ('83', '1', '修改菜单', '/admin.php/system/menu/edit.html', '{\"pid\":\"148\",\"title\":\"\\u6848\\u4f8b\\u5206\\u7c7b\",\"icon\":\"aicon ai-caidan\",\"url\":\"admin\\/caseCategory\\/index\",\"param\":\"\",\"status\":\"1\",\"system\":\"0\",\"nav\":\"1\",\"id\":\"149\",\"module\":\"admin\"}', '保存数据', '8', '27.188.252.74', '1583478981', '1583828370');
INSERT INTO `c_system_log` VALUES ('84', '1', '实训室系列视频', '/admin.php/admin/laboratory_video/index.html', '[]', '浏览数据', '41', '27.188.252.74', '1583479066', '1584501834');
INSERT INTO `c_system_log` VALUES ('85', '1', '实训室系列视频', '/admin.php/admin/laboratory_video/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '41', '27.188.252.74', '1583479067', '1584501834');
INSERT INTO `c_system_log` VALUES ('86', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '5', '127.0.0.1', '1583479097', '1583479314');
INSERT INTO `c_system_log` VALUES ('87', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/edit.html', '{\"la_id\":\"1\",\"name\":\"1231234444\",\"id\":\"1\",\"video\":\"\\/upload\\/product\\/video\\/20200306\\/a893d3e7f4cdd039fcf85e3cd85dc2fd.mp4\",\"download\":\"\\/upload\\/product\\/file\\/20200306\\/0ddf4a298a26c2417988d20de228441f.docx\",\"content\":\"12312312312312312321\"}', '保存数据', '2', '127.0.0.1', '1583479274', '1583479320');
INSERT INTO `c_system_log` VALUES ('88', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/edit.html', '[]', '浏览数据', '1', '127.0.0.1', '1583479286', '1583479286');
INSERT INTO `c_system_log` VALUES ('89', '1', '添加菜单', '/admin.php/system/menu/add/pid/148/mod/admin.html', '{\"pid\":\"148\",\"mod\":\"admin\"}', '浏览数据', '2', '27.188.252.74', '1583748577', '1583826779');
INSERT INTO `c_system_log` VALUES ('90', '1', '修改菜单', '/admin.php/system/menu/edit/id/148/mod/admin.html', '{\"id\":\"148\",\"mod\":\"admin\"}', '浏览数据', '2', '27.188.252.74', '1583749126', '1583749577');
INSERT INTO `c_system_log` VALUES ('91', '1', '修改菜单', '/admin.php/system/menu/edit/id/149/mod/admin.html', '{\"id\":\"149\",\"mod\":\"admin\"}', '浏览数据', '4', '27.188.252.74', '1583749135', '1583828365');
INSERT INTO `c_system_log` VALUES ('92', '1', '案例分类', '/admin.php/admin/cases/index.html', '[]', '浏览数据', '17', '27.188.252.74', '1583749566', '1583826882');
INSERT INTO `c_system_log` VALUES ('93', '1', '案例分类', '/admin.php/admin/cases/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '15', '27.188.252.74', '1583749977', '1583826882');
INSERT INTO `c_system_log` VALUES ('94', '1', '修改菜单', '/admin.php/system/menu/edit/id/144/mod/admin.html', '{\"id\":\"144\",\"mod\":\"admin\"}', '浏览数据', '1', '27.188.252.74', '1583824818', '1583824818');
INSERT INTO `c_system_log` VALUES ('95', '1', '修改菜单', '/admin.php/system/menu/edit/id/145/mod/admin.html', '{\"id\":\"145\",\"mod\":\"admin\"}', '浏览数据', '1', '27.188.252.74', '1583824829', '1583824829');
INSERT INTO `c_system_log` VALUES ('96', '1', '案例列表', '/admin.php/admin/cases/index.html', '[]', '浏览数据', '63', '27.188.252.74', '1583826907', '1584423811');
INSERT INTO `c_system_log` VALUES ('97', '1', '案例列表', '/admin.php/admin/cases/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '63', '27.188.252.74', '1583826907', '1584423811');
INSERT INTO `c_system_log` VALUES ('98', '1', '未加入系统菜单', '/admin.php/admin/case_category/index.html', '[]', '浏览数据', '2', '27.188.252.74', '1583828354', '1583828359');
INSERT INTO `c_system_log` VALUES ('99', '1', '未加入系统菜单', '/admin.php/admin/case_category/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '2', '27.188.252.74', '1583828355', '1583828359');
INSERT INTO `c_system_log` VALUES ('100', '1', '案例分类', '/admin.php/admin/case_category/index.html', '[]', '浏览数据', '32', '27.188.252.74', '1583828376', '1584430702');
INSERT INTO `c_system_log` VALUES ('101', '1', '案例分类', '/admin.php/admin/case_category/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '32', '27.188.252.74', '1583828376', '1584430702');
INSERT INTO `c_system_log` VALUES ('102', '1', '视频库分类', '/admin.php/admin/video_category/index.html', '[]', '浏览数据', '27', '27.188.252.74', '1583976981', '1584512901');
INSERT INTO `c_system_log` VALUES ('103', '1', '视频库分类', '/admin.php/admin/video_category/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '27', '27.188.252.74', '1583976981', '1584512901');
INSERT INTO `c_system_log` VALUES ('104', '1', '视频库', '/admin.php/admin/video/index.html', '[]', '浏览数据', '62', '27.188.252.74', '1583976982', '1584586547');
INSERT INTO `c_system_log` VALUES ('105', '1', '视频库', '/admin.php/admin/video/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '62', '27.188.252.74', '1583976982', '1584586547');
INSERT INTO `c_system_log` VALUES ('106', '1', '未加入系统菜单', '/admin.php/admin/video/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '11', '27.188.252.74', '1583976984', '1584586038');
INSERT INTO `c_system_log` VALUES ('107', '1', '未加入系统菜单', '/admin.php/admin/banner/get_data.html', '{\"type\":\"2\"}', '保存数据', '10', '27.188.252.74', '1583977070', '1584417171');
INSERT INTO `c_system_log` VALUES ('108', '1', '未加入系统菜单', '/admin.php/admin/case_category/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '7', '27.188.252.74', '1583979434', '1584414561');
INSERT INTO `c_system_log` VALUES ('109', '1', '添加菜单', '/admin.php/system/menu/add/pid/152/mod/admin.html', '{\"pid\":\"152\",\"mod\":\"admin\"}', '浏览数据', '1', '27.188.252.74', '1583981473', '1583981473');
INSERT INTO `c_system_log` VALUES ('110', '1', '设置主推视频', '/admin.php/admin/video/main.html', '[]', '浏览数据', '22', '27.188.252.74', '1583981527', '1584583162');
INSERT INTO `c_system_log` VALUES ('111', '1', '未加入系统菜单', '/admin.php/admin/category/edit.html?id=5&hisi_iframe=yes', '{\"id\":\"5\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1583996911', '1583996911');
INSERT INTO `c_system_log` VALUES ('112', '1', '未加入系统菜单', '/admin.php/admin/category/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1583996914', '1583996914');
INSERT INTO `c_system_log` VALUES ('113', '1', '未加入系统菜单', '/admin.php/admin/category/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1583996926', '1583996926');
INSERT INTO `c_system_log` VALUES ('114', '1', '设置主推视频', '/admin.php/admin/video/main.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '19', '27.188.252.74', '1583997371', '1584583162');
INSERT INTO `c_system_log` VALUES ('115', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '26', '27.188.252.74', '1584001292', '1584583330');
INSERT INTO `c_system_log` VALUES ('116', '1', '未加入系统菜单', '/admin.php/admin/banner/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '5', '27.188.252.74', '1584001627', '1584417135');
INSERT INTO `c_system_log` VALUES ('117', '1', '未加入系统菜单', '/admin.php/admin/case_category/add.html', '{\"category_name\":\"\\u897f\\u5357\\u5730\\u533a\"}', '保存数据', '6', '27.188.252.74', '1584003387', '1584414565');
INSERT INTO `c_system_log` VALUES ('118', '1', '未加入系统菜单', '/admin.php/admin/cases/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '10', '27.188.252.74', '1584003429', '1584415843');
INSERT INTO `c_system_log` VALUES ('119', '1', '附件上传', '/admin.php/system/annex/upload/group/case/thumb/100x100/water/no.html', '{\"group\":\"case\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '7', '27.188.252.74', '1584003526', '1584416330');
INSERT INTO `c_system_log` VALUES ('120', '1', '未加入系统菜单', '/admin.php/admin/cases/upload/group/product/thumb/200/water/no.html', '{\"group\":\"product\",\"thumb\":\"200\",\"water\":\"no\"}', '保存数据', '5', '27.188.252.74', '1584003552', '1584096099');
INSERT INTO `c_system_log` VALUES ('121', '1', '未加入系统菜单', '/admin.php/admin/cases/add.html', '{\"category_id\":\"5\",\"title\":\"\\u5409\\u6797\\u5927\\u5b66\\u5317\\u65b9\\u7814\\u7a76\\u5b9e\\u8bad\\u5ba4\",\"image\":\"\\/upload\\/case\\/image\\/0a\\/d449e60d8453d8fdb291040bafea98.jpg\",\"content\":\"&lt;p&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/6e\\/c308f30fae3ebd76e5745bc75ac62e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; \\u5409\\u6797\\u5927\\u5b66\\u6c7d\\u8f66\\u5de5\\u7a0b\\u5b66\\u9662\\u6210\\u7acb\\u4e8e1955\\u5e74\\uff0c\\u5176\\u8f66\\u8f86\\u5de5\\u7a0b\\u5b66\\u79d1\\u662f\\u56fd\\u5185\\u6c7d\\u8f66\\u9886\\u57df\\u6700\\u65e9\\u7684\\u56fd\\u5bb6\\u7ea7\\u91cd\\u70b9\\u5b66\\u79d1\\uff0c\\u62e5\\u6709\\u6c7d\\u8f66\\u4eff\\u771f\\u4e0e\\u63a7\\u5236\\u56fd\\u5bb6\\u91cd\\u70b9\\u5b9e\\u9a8c\\u5ba4\\u3002\\u6c7d\\u8f66\\u5b66\\u9662\\u62e5\\u6709\\u4ee5\\u4e2d\\u56fd\\u5de5\\u7a0b\\u9662\\u9662\\u58eb\\u90ed\\u5b54\\u8f89\\u6559\\u6388\\u4e3a\\u6838\\u5fc3\\u7684200\\u591a\\u540d\\u6559\\u5e08\\u7ec4\\u6210\\u7684\\u6559\\u5b66\\u548c\\u79d1\\u7814\\u961f\\u4f0d\\uff0c\\u521b\\u65b0\\u7814\\u53d1\\u4e86\\u4e00\\u7cfb\\u5217\\u5148\\u8fdb\\u8bbe\\u8ba1\\u7406\\u8bba\\u3001\\u6280\\u672f\\u65b9\\u6cd5\\u3001\\u8f6f\\u4ef6\\u5e73\\u53f0\\u548c\\u91cd\\u5927\\u5b9e\\u9a8c\\u88c5\\u5907\\uff0c\\u4e3a\\u6211\\u56fd\\u4e3b\\u8981\\u6c7d\\u8f66\\u4f01\\u4e1a\\u7684\\u81ea\\u4e3b\\u521b\\u65b0\\u80fd\\u529b\\u5efa\\u8bbe\\u505a\\u51fa\\u4e86\\u91cd\\u8981\\u8d21\\u732e\\u3002&lt;\\/span&gt;&lt;\\/p&gt;\"}', '保存数据', '5', '27.188.252.74', '1584003686', '1584415895');
INSERT INTO `c_system_log` VALUES ('122', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '14', '27.188.252.74', '1584003696', '1584416394');
INSERT INTO `c_system_log` VALUES ('123', '1', '未加入系统菜单', '/admin.php/admin/video/add_main.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '4', '27.188.252.74', '1584003740', '1584417316');
INSERT INTO `c_system_log` VALUES ('124', '1', '未加入系统菜单', '/admin.php/admin/case_category/edit.html?id=5&hisi_iframe=yes', '{\"id\":\"5\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584004644', '1584004698');
INSERT INTO `c_system_log` VALUES ('125', '1', '未加入系统菜单', '/admin.php/admin/case_category/edit.html', '{\"category_name\":\"\\u4e1c\\u5317\\u5730\\u533a\",\"id\":\"5\"}', '保存数据', '5', '27.188.252.74', '1584004647', '1584004701');
INSERT INTO `c_system_log` VALUES ('126', '1', '未加入系统菜单', '/admin.php/admin/case_category/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1584004670', '1584004684');
INSERT INTO `c_system_log` VALUES ('127', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '6', '27.188.252.74', '1584004711', '1584416422');
INSERT INTO `c_system_log` VALUES ('128', '1', '未加入系统菜单', '/admin.php/admin/video_category/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '5', '27.188.252.74', '1584065800', '1584066142');
INSERT INTO `c_system_log` VALUES ('129', '1', '未加入系统菜单', '/admin.php/admin/video_category/add.html', '{\"name\":\"\\u65b0\\u80fd\\u6e90\"}', '保存数据', '4', '27.188.252.74', '1584065843', '1584066158');
INSERT INTO `c_system_log` VALUES ('130', '1', '未加入系统菜单', '/admin.php/admin/video_category/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '4', '27.188.252.74', '1584065865', '1584065893');
INSERT INTO `c_system_log` VALUES ('131', '1', '未加入系统菜单', '/admin.php/admin/video_category/del.html?id=1', '{\"id\":\"1\"}', '浏览数据', '1', '27.188.252.74', '1584065912', '1584065912');
INSERT INTO `c_system_log` VALUES ('132', '1', '未加入系统菜单', '/admin.php/admin/video_category/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1584065913', '1584066101');
INSERT INTO `c_system_log` VALUES ('133', '1', '未加入系统菜单', '/admin.php/admin/video/add.html', '{\"vc_id\":\"2\",\"video_name\":\"\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e933333\",\"image\":\"\\/upload\\/video\\/image\\/88\\/ddb189f72fb538b423e84c93bfa751.jpg\",\"video\":\"\\/upload\\/laboratory\\/video\\/20200316\\/ba9d694bf0b2cc259546620e93480210.mp4\",\"introduction\":\"&lt;p&gt;\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e\\u6d4b\\u8bd5\\u89c6\\u9891\\u5e93\\u6570\\u636e&lt;\\/p&gt;&lt;p&gt;&lt;img src=&quot;\\/upload\\/video\\/image\\/88\\/ddb189f72fb538b423e84c93bfa751.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;br&gt;&lt;\\/p&gt;&lt;p&gt;\\u6d4b\\u8bd5\\u6d4b\\u8bd5\\u6d4b\\u8bd5&lt;\\/p&gt;\",\"type\":\"2\"}', '保存数据', '4', '27.188.252.74', '1584066268', '1584346383');
INSERT INTO `c_system_log` VALUES ('134', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '16', '27.188.252.74', '1584066288', '1584586541');
INSERT INTO `c_system_log` VALUES ('135', '1', '框架升级', '/admin.php/system/upgrade/index.html', '[]', '浏览数据', '1', '27.188.252.74', '1584087265', '1584087265');
INSERT INTO `c_system_log` VALUES ('136', '1', '应用市场', '/admin.php/system/store/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '2', '27.188.252.74', '1584087268', '1584351802');
INSERT INTO `c_system_log` VALUES ('137', '1', '本地插件', '/admin.php/system/plugins/index.html', '[]', '浏览数据', '2', '27.188.252.74', '1584087271', '1584351804');
INSERT INTO `c_system_log` VALUES ('138', '1', '应用市场', '/admin.php/system/store/index.html?type=2', '{\"type\":\"2\"}', '浏览数据', '1', '27.188.252.74', '1584087273', '1584087273');
INSERT INTO `c_system_log` VALUES ('139', '1', '应用市场', '/admin.php/system/store/index/type/2.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\",\"type\":\"2\"}', '浏览数据', '1', '27.188.252.74', '1584087274', '1584087274');
INSERT INTO `c_system_log` VALUES ('140', '1', '实训室分类', '/admin.php/admin/laboratory_category/index.html', '[]', '浏览数据', '22', '27.188.252.74', '1584094391', '1584500779');
INSERT INTO `c_system_log` VALUES ('141', '1', '实训室分类', '/admin.php/admin/laboratory_category/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '22', '27.188.252.74', '1584094391', '1584500781');
INSERT INTO `c_system_log` VALUES ('142', '1', '未加入系统菜单', '/admin.php/admin/cases/upload/group/case/thumb/100x100/water/no.html', '{\"group\":\"case\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '49', '27.188.252.74', '1584096393', '1584416374');
INSERT INTO `c_system_log` VALUES ('143', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html', '{\"category_id\":\"6\",\"title\":\"\\u5e7f\\u5143\\u5e02\\u804c\\u4e1a\\u9ad8\\u7ea7\\u4e2d\\u5b66\\u667a\\u6167\\u6559\\u5b66\\u5b9e\\u8bad\\u5ba4\",\"id\":\"4\",\"image\":\"\\/upload\\/case\\/image\\/10\\/7fa036077eccd349470ea08a11520a.jpg\",\"content\":\"&lt;p&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/e1\\/5dfde508fb174cc86c38dd48033ac8.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; \\u56db\\u5ddd\\u7701\\u5e7f\\u5143\\u5e02\\u804c\\u4e1a\\u9ad8\\u7ea7\\u4e2d\\u5b66\\u6821\\u521b\\u529e\\u4e8e1985\\u5e74\\uff0c\\u524d\\u8eab\\u4e3a\\u5e7f\\u5143\\u5e02\\u8f7b\\u5316\\u5de5\\u4e1a\\u6280\\u5de5\\u5b66\\u6821\\uff0c2004\\u5e74\\u4e0e\\u5e02\\u65c5\\u6e38\\u804c\\u4e1a\\u6280\\u672f\\u5b66\\u6821\\uff08\\u539f\\u5546\\u4e1a\\u6280\\u6821\\uff09\\u6574\\u5408\\uff0c2007\\u5e74\\u8fdb\\u5165\\u6559\\u80b2\\u56ed\\u533a\\uff0c\\u76f4\\u5c5e\\u5e7f\\u5143\\u5e02\\u6559\\u80b2\\u5c40\\uff0c\\u662f\\u96c6\\u5b66\\u5386\\u6559\\u80b2\\u3001\\u804c\\u4e1a\\u6280\\u80fd\\u57f9\\u8bad\\u4e0e\\u9274\\u5b9a\\u548c\\u5c31\\u4e1a\\u6307\\u5bfc\\u670d\\u52a1\\u4e8e\\u4e00\\u4f53\\u7684\\u73b0\\u4ee3\\u5316\\u804c\\u4e1a\\u5b66\\u6821\\u3002\\u4e3a\\u56fd\\u5bb6\\u7ea7\\u91cd\\u70b9\\u4e2d\\u7b49\\u804c\\u4e1a\\u5b66\\u6821\\uff0c\\u56fd\\u5bb6\\u4e2d\\u7b49\\u804c\\u4e1a\\u6559\\u80b2\\u6539\\u9769\\u53d1\\u5c55\\u793a\\u8303\\u5b66\\u6821\\uff0c\\u85cf\\u533a\\u201c9+3\\u201d\\u514d\\u8d39\\u6559\\u80b2\\u8ba1\\u5212\\u5b9e\\u65bd\\u5b66\\u6821\\uff0c\\u56db\\u5ddd\\u7701\\u6559\\u80b2\\u4f53\\u5236\\u6539\\u9769\\u8bd5\\u70b9\\u9879\\u76ee\\u201c\\u4ea7\\u6559\\u878d\\u5408\\u673a\\u5236\\u5efa\\u8bbe\\u201d\\u91cd\\u70b9\\u5b66\\u6821\\u3002&lt;\\/p&gt;&lt;p&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/13\\/086ca6124701ea17719ea2e198c75e.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/77\\/2027f2e6bee2a65ffd716bdf3a74ce.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/39\\/618cb53720b2ff8566095ae35e0b07.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/59\\/b431537e728fc4ff6b59a699710066.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/be\\/08e5a04e73f438bf68a5edb2616341.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/d2\\/3710fb93cbb959cc825154a8812110.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/c7\\/8a59e018865ddbf62f4c1072a9a547.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/0a\\/c65d6f5c7aab4a528ea3f5f78fe34a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/bd\\/fcb290fc2c74dcaf1cdc8e1da97005.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/c0\\/ef71eb15d4e4ad189f60fede2f2406.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/73\\/18c57971314d6cd6e708ca4ec21eb6.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/case\\/image\\/90\\/3f62c46eaf769403707da2db830f3a.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;\"}', '保存数据', '12', '27.188.252.74', '1584096520', '1584423808');
INSERT INTO `c_system_log` VALUES ('144', '1', '反馈列表', '/admin.php/admin/feedback/index.html', '[]', '浏览数据', '18', '27.188.252.74', '1584174653', '1584436179');
INSERT INTO `c_system_log` VALUES ('145', '1', '反馈列表', '/admin.php/admin/feedback/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '17', '27.188.252.74', '1584174653', '1584436180');
INSERT INTO `c_system_log` VALUES ('146', '1', '公司简介', '/admin.php/admin/company/index.html', '[]', '浏览数据', '17', '27.188.252.74', '1584175733', '1584436177');
INSERT INTO `c_system_log` VALUES ('147', '1', '公司简介', '/admin.php/admin/company/index.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '17', '27.188.252.74', '1584175733', '1584436178');
INSERT INTO `c_system_log` VALUES ('148', '1', '未加入系统菜单', '/admin.php/admin/company/edit.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '11', '27.188.252.74', '1584175735', '1584430697');
INSERT INTO `c_system_log` VALUES ('149', '1', '未加入系统菜单', '/admin.php/admin/company/edit.html', '{\"content\":\"&lt;p style=&quot;text-align: left;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; \\u5317\\u65b9\\u804c\\u4e1a\\u6559\\u80b2\\u7814\\u7a76\\u9662\\u96b6\\u5c5e\\u4e8e\\u4e2d\\u56fd\\u5317\\u65b9\\u56fd\\u9645\\u6c7d\\u8f66\\u6559\\u80b2\\u96c6\\u56e2\\uff0c\\u81f4\\u529b\\u4e8e\\u6c7d\\u8f66\\u6559\\u80b2\\u88c5\\u590727\\u5e74\\uff0c\\u662f\\u56fd\\u5185\\u6700\\u5927\\u751f\\u4ea7\\u89c4\\u6a21\\uff0c\\u7814\\u53d1\\u5b9e\\u529b\\u6700\\u5f3a\\u7684\\u6c7d\\u8f66\\u6559\\u80b2\\u6574\\u4f53\\u89e3\\u51b3\\u65b9\\u6848\\u4f9b\\u5e94\\u5546\\u3002      \\u63d0\\u4f9b\\u5b9e\\u8bad\\u5ba4\\u6574\\u4f53\\u8bbe\\u8ba1\\u3001\\u6559\\u5177\\u7814\\u53d1\\u3001\\u667a\\u9020\\u3001\\u8bfe\\u7a0b\\u4f53\\u7cfb\\u3001\\u5e08\\u8d44\\u57f9\\u8bad\\u3001\\u6559\\u6750\\u7f16\\u64b0\\u3001\\u5b66\\u751f\\u521b\\u5c31\\u4e1a\\u4f53\\u7cfb\\u3002&lt;\\/p&gt;&lt;p style=&quot;text-align: left;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;\\u5f15\\u8fdb\\u5fb7\\u56fd\\u53cc\\u5143\\u5236\\u6559\\u80b2\\u4f53\\u7cfb\\uff0c\\u7ed3\\u5408\\u4e2d\\u56fd\\u804c\\u4e1a\\u6559\\u80b2\\u7279\\u70b9\\uff0c\\u7814\\u53d1\\u9002\\u5408\\u4e2d\\u56fd\\u56fd\\u60c5\\u7684\\u8bfe\\u7a0b\\u4f53\\u7cfb\\u548c\\u6559\\u80b2\\u88c5\\u5907\\u3002&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 912\\u9879\\u4e13\\u5229\\u6280\\u672f\\uff0c\\u6db5\\u76d6\\u6559\\u5177\\u7814\\u53d1\\u3001\\u667a\\u9020\\uff0c\\u8bfe\\u7a0b\\u4f53\\u7cfb\\u8bbe\\u8ba1\\uff0c\\u8bfe\\u4ef6\\u7f16\\u5236\\uff0c\\u7f51\\u7edc\\u5b66\\u4e60\\u3001\\u8f6f\\u4ef6\\u5f00\\u53d1\\u7b49\\u6c7d\\u8f66\\u6559\\u80b2\\u6240\\u9700\\u3002&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; \\u4e0e\\u4e2d\\u56fd\\u6c7d\\u8f66\\u6280\\u672f\\u7814\\u7a76\\u4e2d\\u5fc3\\u548c\\u6559\\u80b2\\u90e8\\u804c\\u6559\\u53f8\\u5408\\u4f5c\\uff0c\\u4e3a300\\u591a\\u5bb6\\u4e2d\\u9ad8\\u804c\\u9662\\u63d0\\u4f9b\\u670d\\u52a1\\u548c\\u4ea7\\u54c1\\u3002      \\u6559\\u5177\\u884c\\u4e1a\\u552f\\u4e00\\u88c5\\u5907\\u4e24\\u6761\\u81ea\\u52a8\\u6d41\\u6c34\\u7ebf\\u7684\\u667a\\u9020\\u5382\\u5bb6\\uff0c8000\\u53f0\\u7684\\u5e74\\u751f\\u4ea7\\u80fd\\u529b\\uff0c\\u53ef\\u4ee5\\u6ee1\\u8db3\\u4ece\\u6574\\u8f66\\u5230\\u90e8\\u4ef6\\uff0c\\u4ece\\u4e2d\\u804c\\u5230211\\u3001985\\u6240\\u9700\\u7684\\u670d\\u52a1\\u548c\\u4ea7\\u54c1\\u3002&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p style=&quot;text-align: left;&quot;&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/company\\/image\\/f6\\/4caa4a0629e596df6b05c9689d70fa.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;\\u5168\\u6d41\\u7a0b\\u4ea4\\u94a5\\u5319\\u5de5\\u7a0b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 1\\u3001\\u7cfb\\u7edf\\u89c4\\u5212\\uff1a\\u7acb\\u8db3\\u56fd\\u9645\\u56fd\\u5185\\u6700\\u4f18\\u79c0\\u6c7d\\u8f66\\u804c\\u4e1a\\u4f53\\u7cfb\\u7cfb\\u7edf\\u89c4\\u5212\\uff1b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 2\\u3001\\u4e3b\\u9898\\u88c5\\u4fee\\uff1a\\u878d\\u6c7d\\u8f66\\u79d1\\u6280\\u3001\\u5de5\\u4e1a\\u6587\\u5316\\u3001\\u827a\\u672f\\u8bbe\\u8ba1\\u7b49\\u4e3b\\u9898\\u8bbe\\u8ba1\\uff1b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 3\\u3001\\u4e13\\u9879\\u7814\\u53d1\\uff1a\\u7acb\\u8db3\\u5f53\\u5730\\u5e02\\u573a\\uff0c\\u5f25\\u8865\\u9700\\u65b9\\u52a3\\u52bf\\uff1b&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 4\\u3001\\u5feb\\u901f\\u751f\\u4ea7\\uff1a\\u4e03\\u65e5\\u4ea4\\u9a8c\\uff1b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 5\\u3001\\u4e13\\u4e1a\\u5b89\\u88c5\\uff1a\\u4e13\\u4e1a\\u961f\\u4f0d\\u3001\\u4e13\\u5c5e\\u6807\\u51c6\\uff1b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 6\\u3001\\u7cbe\\u51c6\\u8c03\\u8bd5\\uff1a\\u786c\\u4ef6\\u3001\\u8f6f\\u4ef6\\u3001\\u7f51\\u7edc\\u4f53\\u7cfb\\u4e92\\u878d\\u4e92\\u901a\\uff1b&lt;\\/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 7\\u3001\\u5ef6\\u4f38\\u670d\\u52a1\\uff1a\\u5e08\\u8d44\\u57f9\\u8bad\\u3001\\u6280\\u80fd\\u5145\\u7535\\u3001\\u4f53\\u7cfb\\u5347\\u7ea7\\u3001\\u7f51\\u70b9\\u652f\\u6491\\uff1b&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; \\uff08\\u5206\\u5e03\\u5168\\u56fd\\u7684\\u5b66\\u6821\\u90fd\\u662f\\u4f60\\u7684\\u670d\\u52a1\\u7f51\\u70b9\\u3001\\u8d4b\\u80fd\\u7f51\\u70b9\\uff09&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;&lt;p&gt;&lt;\\/p&gt;\",\"id\":\"1\"}', '保存数据', '8', '27.188.252.74', '1584176644', '1584430515');
INSERT INTO `c_system_log` VALUES ('150', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/add.html?hisi_iframe=yes', '{\"hisi_iframe\":\"yes\"}', '浏览数据', '7', '27.188.252.74', '1584345258', '1584350804');
INSERT INTO `c_system_log` VALUES ('151', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/add.html', '{\"category_name\":\"\\u5176\\u5b83\\u5b9e\\u8bad\\u5ba4\"}', '保存数据', '6', '27.188.252.74', '1584345285', '1584350664');
INSERT INTO `c_system_log` VALUES ('152', '1', '附件上传', '/admin.php/system/annex/upload/group/video/thumb/100x100/water/no.html', '{\"group\":\"video\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '8', '27.188.252.74', '1584346203', '1584582381');
INSERT INTO `c_system_log` VALUES ('153', '1', '未加入系统菜单', '/admin.php/admin/video/upload_file/type/video.html', '{\"type\":\"video\"}', '保存数据', '7', '27.188.252.74', '1584346207', '1584582432');
INSERT INTO `c_system_log` VALUES ('154', '1', '未加入系统菜单', '/admin.php/admin/video/upload/group/video/thumb/200/water/no.html', '{\"group\":\"video\",\"thumb\":\"200\",\"water\":\"no\"}', '保存数据', '5', '27.188.252.74', '1584346374', '1584582375');
INSERT INTO `c_system_log` VALUES ('155', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/del.html?id=1', '{\"id\":\"1\"}', '浏览数据', '1', '27.188.252.74', '1584347362', '1584347362');
INSERT INTO `c_system_log` VALUES ('156', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/del.html?id=2', '{\"id\":\"2\"}', '浏览数据', '1', '27.188.252.74', '1584347364', '1584347364');
INSERT INTO `c_system_log` VALUES ('157', '1', '状态设置', '/admin.php/system/menu/status/table/admin_menu/id/150.html?val=0', '{\"val\":\"0\",\"table\":\"admin_menu\",\"id\":\"150\"}', '浏览数据', '1', '27.188.252.74', '1584347427', '1584347427');
INSERT INTO `c_system_log` VALUES ('158', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html?id=4&hisi_iframe=yes', '{\"id\":\"4\",\"hisi_iframe\":\"yes\"}', '浏览数据', '4', '27.188.252.74', '1584347445', '1584586036');
INSERT INTO `c_system_log` VALUES ('159', '1', '联系我们', '/admin.php/admin/company/telindex.html', '[]', '浏览数据', '6', '27.188.252.74', '1584347476', '1584434372');
INSERT INTO `c_system_log` VALUES ('160', '1', '联系我们', '/admin.php/admin/company/telindex.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '6', '27.188.252.74', '1584347476', '1584434373');
INSERT INTO `c_system_log` VALUES ('161', '1', '未加入系统菜单', '/admin.php/admin/company/teledit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584347477', '1584434352');
INSERT INTO `c_system_log` VALUES ('162', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/del.html?id=6', '{\"id\":\"6\"}', '浏览数据', '1', '27.188.252.74', '1584350568', '1584350568');
INSERT INTO `c_system_log` VALUES ('163', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/edit.html?id=7&hisi_iframe=yes', '{\"id\":\"7\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584350628', '1584350628');
INSERT INTO `c_system_log` VALUES ('164', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/edit.html', '{\"category_name\":\"\\u7eaf\\u7535\\u52a8\\u6c7d\\u8f66\",\"id\":\"4\"}', '保存数据', '2', '27.188.252.74', '1584350644', '1584500776');
INSERT INTO `c_system_log` VALUES ('165', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '4', '27.188.252.74', '1584351478', '1584351601');
INSERT INTO `c_system_log` VALUES ('166', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/del.html?id=8', '{\"id\":\"8\"}', '浏览数据', '1', '27.188.252.74', '1584351587', '1584351587');
INSERT INTO `c_system_log` VALUES ('167', '1', '备份数据库', '/admin.php/system/database/export.html', '{\"id\":[\"c_banner\",\"c_case\",\"c_case_category\",\"c_comment\",\"c_company\",\"c_fabulous\",\"c_feedback\",\"c_jobs\",\"c_laboratory\",\"c_laboratory_category\",\"c_laboratory_video\",\"c_product\",\"c_product_category\",\"c_system_annex\",\"c_system_annex_group\",\"c_system_config\",\"c_system_hook\",\"c_system_hook_plugins\",\"c_system_language\",\"c_system_log\",\"c_system_menu\",\"c_system_menu_lang\",\"c_system_module\",\"c_system_plugins\",\"c_system_role\",\"c_system_user\",\"c_system_user_role\",\"c_token\",\"c_video_category\",\"c_video_comment\",\"c_video_main\",\"c_videos\"]}', '保存数据', '2', '27.188.252.74', '1584351787', '1584586678');
INSERT INTO `c_system_log` VALUES ('168', '1', '数据库管理', '/admin.php/system/database/index/group/import.html', '{\"group\":\"import\"}', '浏览数据', '2', '27.188.252.74', '1584351788', '1584586579');
INSERT INTO `c_system_log` VALUES ('169', '1', '数据库管理', '/admin.php/system/database/index.html?group=import&page=1&limit=10', '{\"group\":\"import\",\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '2', '27.188.252.74', '1584351789', '1584586580');
INSERT INTO `c_system_log` VALUES ('170', '1', '数据库管理', '/admin.php/system/database/index/group/export.html', '{\"group\":\"export\"}', '浏览数据', '1', '27.188.252.74', '1584351794', '1584351794');
INSERT INTO `c_system_log` VALUES ('171', '1', '插件钩子', '/admin.php/system/hook/index.html', '[]', '浏览数据', '1', '27.188.252.74', '1584351805', '1584351805');
INSERT INTO `c_system_log` VALUES ('172', '1', '插件钩子', '/admin.php/system/hook/index.html?page=1&limit=20', '{\"page\":\"1\",\"limit\":\"20\"}', '浏览数据', '1', '27.188.252.74', '1584351805', '1584351805');
INSERT INTO `c_system_log` VALUES ('173', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=3&val=1', '{\"id\":\"3\",\"val\":\"1\"}', '浏览数据', '2', '27.188.252.74', '1584352849', '1584353376');
INSERT INTO `c_system_log` VALUES ('174', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=4&val=1', '{\"id\":\"4\",\"val\":\"1\"}', '浏览数据', '2', '27.188.252.74', '1584352853', '1584353378');
INSERT INTO `c_system_log` VALUES ('175', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=5&val=1', '{\"id\":\"5\",\"val\":\"1\"}', '浏览数据', '3', '27.188.252.74', '1584352854', '1584353377');
INSERT INTO `c_system_log` VALUES ('176', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=5&val=0', '{\"id\":\"5\",\"val\":\"0\"}', '浏览数据', '2', '27.188.252.74', '1584352960', '1584353355');
INSERT INTO `c_system_log` VALUES ('177', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=2&val=0', '{\"id\":\"2\",\"val\":\"0\"}', '浏览数据', '2', '27.188.252.74', '1584353332', '1584353357');
INSERT INTO `c_system_log` VALUES ('178', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=2&val=1', '{\"id\":\"2\",\"val\":\"1\"}', '浏览数据', '2', '27.188.252.74', '1584353334', '1584353379');
INSERT INTO `c_system_log` VALUES ('179', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=4&val=0', '{\"id\":\"4\",\"val\":\"0\"}', '浏览数据', '1', '27.188.252.74', '1584353355', '1584353355');
INSERT INTO `c_system_log` VALUES ('180', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=3&val=0', '{\"id\":\"3\",\"val\":\"0\"}', '浏览数据', '1', '27.188.252.74', '1584353356', '1584353356');
INSERT INTO `c_system_log` VALUES ('181', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=1&val=0', '{\"id\":\"1\",\"val\":\"0\"}', '浏览数据', '1', '27.188.252.74', '1584353356', '1584353356');
INSERT INTO `c_system_log` VALUES ('182', '1', '未加入系统菜单', '/admin.php/admin/laboratory/is_wisdom.html?id=1&val=1', '{\"id\":\"1\",\"val\":\"1\"}', '浏览数据', '1', '27.188.252.74', '1584353370', '1584353370');
INSERT INTO `c_system_log` VALUES ('183', '1', '未加入系统菜单', '/admin.php/admin/laboratory_video/upload/group/product/thumb/200/water/no.html', '{\"group\":\"product\",\"thumb\":\"200\",\"water\":\"no\"}', '保存数据', '3', '27.188.252.74', '1584409573', '1584500336');
INSERT INTO `c_system_log` VALUES ('184', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=9&hisi_iframe=yes', '{\"id\":\"9\",\"hisi_iframe\":\"yes\"}', '浏览数据', '5', '27.188.252.74', '1584411206', '1584583273');
INSERT INTO `c_system_log` VALUES ('185', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=8&hisi_iframe=yes', '{\"id\":\"8\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584411231', '1584583168');
INSERT INTO `c_system_log` VALUES ('186', '1', '未加入系统菜单', '/admin.php/admin/cases/upload/group/case/thumb/200x200/water/no.html', '{\"group\":\"case\",\"thumb\":\"200x200\",\"water\":\"no\"}', '保存数据', '5', '27.188.252.74', '1584412790', '1584415867');
INSERT INTO `c_system_log` VALUES ('187', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '4', '27.188.252.74', '1584413657', '1584416391');
INSERT INTO `c_system_log` VALUES ('188', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html?id=4&hisi_iframe=yes', '{\"id\":\"4\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584415528', '1584423799');
INSERT INTO `c_system_log` VALUES ('189', '1', '未加入系统菜单', '/admin.php/admin/cases/edit.html?id=5&hisi_iframe=yes', '{\"id\":\"5\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1584416054', '1584416115');
INSERT INTO `c_system_log` VALUES ('190', '1', '未加入系统菜单', '/admin.php/admin/banner/edit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584417153', '1584417153');
INSERT INTO `c_system_log` VALUES ('191', '1', '附件上传', '/admin.php/system/annex/upload/group/videomain/thumb/100x100/water/no.html', '{\"group\":\"videomain\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '4', '27.188.252.74', '1584417310', '1584582909');
INSERT INTO `c_system_log` VALUES ('192', '1', '未加入系统菜单', '/admin.php/admin/video/add_main.html', '{\"data_id\":\"2\",\"image\":\"\\/upload\\/videomain\\/image\\/44\\/95f0147410c6622df86913c343f5e4.jpg\"}', '保存数据', '2', '27.188.252.74', '1584417312', '1584417347');
INSERT INTO `c_system_log` VALUES ('193', '1', '未加入系统菜单', '/admin.php/admin/video/edit_main.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584417364', '1584582873');
INSERT INTO `c_system_log` VALUES ('194', '1', '未加入系统菜单', '/admin.php/admin/company/teledit.html', '{\"content\":\"&lt;p style=&quot;text-align: center;&quot;&gt;\\u5730\\u5740\\uff1a\\u6cb3\\u5317\\u7701\\u90af\\u90f8\\u5e02\\u5e7f\\u5e73\\u53bf\\u5f00\\u53d1\\u533a\\u6606\\u5c71\\u8def\\u4e2d\\u5317\\u6559\\u5177\\u57fa\\u5730&lt;\\/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;\\u7535\\u8bdd\\uff1a0310-2519888&amp;nbsp; 15831036208&amp;nbsp;&lt;\\/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;QQ\\uff1a38090539&lt;\\/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;\\u90ae\\u7bb1\\uff1atouchbon@163.com&lt;\\/p&gt;\",\"id\":\"2\"}', '保存数据', '2', '27.188.252.74', '1584426127', '1584434369');
INSERT INTO `c_system_log` VALUES ('195', '1', '未加入系统菜单', '/admin.php/admin/company/upload/group/company/thumb/100x100/water/no.html', '{\"group\":\"company\",\"thumb\":\"100x100\",\"water\":\"no\"}', '保存数据', '1', '27.188.252.74', '1584427868', '1584427868');
INSERT INTO `c_system_log` VALUES ('196', '1', '修改菜单', '/admin.php/system/menu/edit/id/158/mod/admin.html', '{\"id\":\"158\",\"mod\":\"admin\"}', '浏览数据', '1', '27.188.252.74', '1584436201', '1584436201');
INSERT INTO `c_system_log` VALUES ('197', '1', '修改菜单', '/admin.php/system/menu/edit/id/159/mod/admin.html', '{\"id\":\"159\",\"mod\":\"admin\"}', '浏览数据', '1', '27.188.252.74', '1584436244', '1584436244');
INSERT INTO `c_system_log` VALUES ('198', '1', '管理员角色', '/admin.php/system/user/role.html', '[]', '浏览数据', '1', '27.188.252.74', '1584436269', '1584436269');
INSERT INTO `c_system_log` VALUES ('199', '1', '管理员角色', '/admin.php/system/user/role.html?page=1&limit=10', '{\"page\":\"1\",\"limit\":\"10\"}', '浏览数据', '1', '27.188.252.74', '1584436269', '1584436269');
INSERT INTO `c_system_log` VALUES ('200', '1', '未加入系统菜单', '/admin.php/admin/laboratory_category/edit.html?id=4&hisi_iframe=yes', '{\"id\":\"4\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584500771', '1584500771');
INSERT INTO `c_system_log` VALUES ('201', '1', '未加入系统菜单', '/admin.php/admin/video/edit_main.html?id=1&hisi_iframe=yes', '{\"id\":\"1\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584512851', '1584582898');
INSERT INTO `c_system_log` VALUES ('202', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html', '{\"vc_id\":\"4\",\"video_name\":\"\\u7279\\u65af\\u62c9\\u5e95\\u76d8\\u7535\\u673a\\u7cfb\\u7edf\",\"id\":\"2\",\"image\":\"\\/upload\\/video\\/image\\/86\\/629d15134c91e5492fa138a8ca6fca.jpg\",\"video\":\"\\/upload\\/laboratory\\/video\\/20200319\\/294a489676ae52e7e0575044b6eb5b08.mp4\",\"introduction\":\"&lt;p&gt;&lt;img src=&quot;http:\\/\\/cmf.qc110.cn\\/upload\\/video\\/image\\/76\\/fba63d92367e48a801e3e9fc712879.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;\\/p&gt;\",\"type\":\"1\"}', '保存数据', '10', '27.188.252.74', '1584512897', '1584582435');
INSERT INTO `c_system_log` VALUES ('203', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html?id=3&hisi_iframe=yes', '{\"id\":\"3\",\"hisi_iframe\":\"yes\"}', '浏览数据', '6', '27.188.252.74', '1584582019', '1584585720');
INSERT INTO `c_system_log` VALUES ('204', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html?id=2&hisi_iframe=yes', '{\"id\":\"2\",\"hisi_iframe\":\"yes\"}', '浏览数据', '9', '27.188.252.74', '1584582163', '1584585976');
INSERT INTO `c_system_log` VALUES ('205', '1', '未加入系统菜单', '/admin.php/admin/video/edit_main.html', '{\"data_id\":\"4\",\"image\":\"\\/upload\\/videomain\\/image\\/ba\\/dcfc8b186da384ca9cddb99bf70892.jpg\",\"id\":\"1\"}', '保存数据', '3', '27.188.252.74', '1584582811', '1584582910');
INSERT INTO `c_system_log` VALUES ('206', '1', '实训室列表', '/admin.php/admin/laboratory/index.html?page=2&limit=10', '{\"page\":\"2\",\"limit\":\"10\"}', '浏览数据', '2', '27.188.252.74', '1584583153', '1584583399');
INSERT INTO `c_system_log` VALUES ('207', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=11&hisi_iframe=yes', '{\"id\":\"11\",\"hisi_iframe\":\"yes\"}', '浏览数据', '3', '27.188.252.74', '1584583174', '1584583208');
INSERT INTO `c_system_log` VALUES ('208', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=10&hisi_iframe=yes', '{\"id\":\"10\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584583242', '1584583242');
INSERT INTO `c_system_log` VALUES ('209', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=7&hisi_iframe=yes', '{\"id\":\"7\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1584583291', '1584583298');
INSERT INTO `c_system_log` VALUES ('210', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=6&hisi_iframe=yes', '{\"id\":\"6\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584583317', '1584583317');
INSERT INTO `c_system_log` VALUES ('211', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=4&hisi_iframe=yes', '{\"id\":\"4\",\"hisi_iframe\":\"yes\"}', '浏览数据', '1', '27.188.252.74', '1584583348', '1584583348');
INSERT INTO `c_system_log` VALUES ('212', '1', '未加入系统菜单', '/admin.php/admin/laboratory/edit.html?id=5&hisi_iframe=yes', '{\"id\":\"5\",\"hisi_iframe\":\"yes\"}', '浏览数据', '2', '27.188.252.74', '1584583364', '1584583371');
INSERT INTO `c_system_log` VALUES ('213', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html', '[]', '浏览数据', '2', '27.188.252.74', '1584585545', '1584585684');
INSERT INTO `c_system_log` VALUES ('214', '1', '未加入系统菜单', '/admin.php/admin/video/edit.html?id=3', '{\"id\":\"3\"}', '浏览数据', '1', '27.188.252.74', '1584585812', '1584585812');
INSERT INTO `c_system_log` VALUES ('215', '1', '未加入系统菜单', '/admin.php/admin/video/del.html?id=3', '{\"id\":\"3\"}', '浏览数据', '1', '27.188.252.74', '1584585819', '1584585819');
INSERT INTO `c_system_log` VALUES ('216', '1', '未加入系统菜单', '/admin.php/admin/video/del.html', '[]', '浏览数据', '1', '27.188.252.74', '1584585823', '1584585823');

-- -----------------------------
-- Table structure for `c_system_menu`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_menu`;
CREATE TABLE `c_system_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID(快捷菜单专用)',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(20) NOT NULL COMMENT '模块名或插件名，插件名格式:plugins.插件名',
  `title` varchar(20) NOT NULL COMMENT '菜单标题',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-shezhi' COMMENT '菜单图标',
  `url` varchar(200) NOT NULL COMMENT '链接地址(模块/控制器/方法)',
  `param` varchar(200) NOT NULL DEFAULT '' COMMENT '扩展参数',
  `target` varchar(20) NOT NULL DEFAULT '_self' COMMENT '打开方式(_blank,_self)',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `debug` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '开发模式可见',
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `nav` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否为菜单显示，1显示0不显示',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态1显示，0隐藏',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 管理菜单';

-- -----------------------------
-- Records of `c_system_menu`
-- -----------------------------
INSERT INTO `c_system_menu` VALUES ('1', '0', '0', 'system', '首页', '', 'system/index', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('2', '0', '0', 'system', '系统', '', 'system/system', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('3', '0', '0', 'system', '插件', 'aicon ai-shezhi', 'system/plugins', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('4', '0', '1', 'system', '快捷菜单', 'aicon ai-caidan', 'system/quick', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('5', '0', '3', 'system', '插件列表', 'aicon ai-mokuaiguanli', 'system/plugins', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('6', '0', '2', 'system', '系统基础', 'aicon ai-gongneng', 'system/system', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('7', '0', '17', 'system', '导入主题SQL', '', 'system/module/exeSql', '', '_self', '10', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('8', '0', '2', 'system', '系统扩展', 'aicon ai-shezhi', 'system/extend', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('9', '0', '4', 'system', '预留占位', '', '', '', '_self', '4', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('10', '0', '6', 'system', '系统设置', 'aicon ai-icon01', 'system/system/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('11', '0', '6', 'system', '配置管理', 'aicon ai-peizhiguanli', 'system/config/index', '', '_self', '2', '1', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('12', '0', '6', 'system', '系统菜单', 'aicon ai-systemmenu', 'system/menu/index', '', '_self', '3', '1', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('13', '0', '6', 'system', '管理员角色', '', 'system/user/role', '', '_self', '4', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('14', '0', '6', 'system', '系统管理员', 'aicon ai-tubiao05', 'system/user/index', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('15', '0', '6', 'system', '系统日志', 'aicon ai-xitongrizhi-tiaoshi', 'system/log/index', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('16', '0', '6', 'system', '附件管理', '', 'system/annex/index', '', '_self', '8', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('17', '0', '8', 'system', '本地模块', 'aicon ai-mokuaiguanli1', 'system/module/index', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('18', '0', '8', 'system', '本地插件', 'aicon ai-chajianguanli', 'system/plugins/index', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('19', '0', '8', 'system', '插件钩子', 'aicon ai-icon-test', 'system/hook/index', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('20', '0', '4', 'system', '预留占位', '', '', '', '_self', '1', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('21', '0', '4', 'system', '预留占位', '', '', '', '_self', '2', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('22', '0', '4', 'system', '预留占位', '', '', '', '_self', '1', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('23', '0', '4', 'system', '预留占位', '', '', '', '_self', '2', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('24', '0', '4', 'system', '后台首页', '', 'system/index/index', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('25', '0', '4', 'system', '清空缓存', '', 'system/index/clear', '', '_self', '2', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('26', '0', '12', 'system', '添加菜单', '', 'system/menu/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('27', '0', '12', 'system', '修改菜单', '', 'system/menu/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('28', '0', '12', 'system', '删除菜单', '', 'system/menu/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('29', '0', '12', 'system', '状态设置', '', 'system/menu/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('30', '0', '12', 'system', '排序设置', '', 'system/menu/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('31', '0', '12', 'system', '添加快捷菜单', '', 'system/menu/quick', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('32', '0', '12', 'system', '导出菜单', '', 'system/menu/export', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('33', '0', '13', 'system', '添加角色', '', 'system/user/addrole', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('34', '0', '13', 'system', '修改角色', '', 'system/user/editrole', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('35', '0', '13', 'system', '删除角色', '', 'system/user/delrole', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('36', '0', '13', 'system', '状态设置', '', 'system/user/statusRole', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('37', '0', '14', 'system', '添加管理员', '', 'system/user/adduser', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('38', '0', '14', 'system', '修改管理员', '', 'system/user/edituser', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('39', '0', '14', 'system', '删除管理员', '', 'system/user/deluser', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('40', '0', '14', 'system', '状态设置', '', 'system/user/status', '', '_self', '4', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('41', '0', '4', 'system', '个人信息设置', '', 'system/user/info', '', '_self', '5', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('42', '0', '18', 'system', '安装插件', '', 'system/plugins/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('43', '0', '18', 'system', '卸载插件', '', 'system/plugins/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('44', '0', '18', 'system', '删除插件', '', 'system/plugins/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('45', '0', '18', 'system', '状态设置', '', 'system/plugins/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('46', '0', '18', 'system', '生成插件', '', 'system/plugins/design', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('47', '0', '18', 'system', '运行插件', '', 'system/plugins/run', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('48', '0', '18', 'system', '更新插件', '', 'system/plugins/update', '', '_self', '7', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('49', '0', '18', 'system', '插件配置', '', 'system/plugins/setting', '', '_self', '8', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('50', '0', '19', 'system', '添加钩子', '', 'system/hook/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('51', '0', '19', 'system', '修改钩子', '', 'system/hook/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('52', '0', '19', 'system', '删除钩子', '', 'system/hook/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('53', '0', '19', 'system', '状态设置', '', 'system/hook/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('54', '0', '19', 'system', '插件排序', '', 'system/hook/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('55', '0', '11', 'system', '添加配置', '', 'system/config/add', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('56', '0', '11', 'system', '修改配置', '', 'system/config/edit', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('57', '0', '11', 'system', '删除配置', '', 'system/config/del', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('58', '0', '11', 'system', '状态设置', '', 'system/config/status', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('59', '0', '11', 'system', '排序设置', '', 'system/config/sort', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('60', '0', '10', 'system', '基础配置', '', 'system/system/index', 'group=base', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('61', '0', '10', 'system', '系统配置', '', 'system/system/index', 'group=sys', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('62', '0', '10', 'system', '上传配置', '', 'system/system/index', 'group=upload', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('63', '0', '10', 'system', '开发配置', '', 'system/system/index', 'group=develop', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('64', '0', '17', 'system', '生成模块', '', 'system/module/design', '', '_self', '6', '1', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('65', '0', '17', 'system', '安装模块', '', 'system/module/install', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('66', '0', '17', 'system', '卸载模块', '', 'system/module/uninstall', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('67', '0', '17', 'system', '状态设置', '', 'system/module/status', '', '_self', '3', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('68', '0', '17', 'system', '设置默认模块', '', 'system/module/setdefault', '', '_self', '4', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('69', '0', '17', 'system', '删除模块', '', 'system/module/del', '', '_self', '5', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('70', '0', '4', 'system', '预留占位', '', '', '', '_self', '1', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('71', '0', '4', 'system', '预留占位', '', '', '', '_self', '2', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('72', '0', '4', 'system', '预留占位', '', '', '', '_self', '3', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('73', '0', '4', 'system', '预留占位', '', '', '', '_self', '4', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('74', '0', '4', 'system', '预留占位', '', '', '', '_self', '5', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('75', '0', '4', 'system', '预留占位', '', '', '', '_self', '0', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('76', '0', '4', 'system', '预留占位', '', '', '', '_self', '0', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('77', '0', '4', 'system', '预留占位', '', '', '', '_self', '0', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('78', '0', '16', 'system', '附件上传', '', 'system/annex/upload', '', '_self', '1', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('79', '0', '16', 'system', '删除附件', '', 'system/annex/del', '', '_self', '2', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('80', '0', '8', 'system', '框架升级', 'aicon ai-iconfontshengji', 'system/upgrade/index', '', '_self', '4', '0', '1', '1', '1', '1491352728');
INSERT INTO `c_system_menu` VALUES ('81', '0', '80', 'system', '获取升级列表', '', 'system/upgrade/lists', '', '_self', '0', '0', '1', '1', '1', '1491353504');
INSERT INTO `c_system_menu` VALUES ('82', '0', '80', 'system', '安装升级包', '', 'system/upgrade/install', '', '_self', '0', '0', '1', '1', '1', '1491353568');
INSERT INTO `c_system_menu` VALUES ('83', '0', '80', 'system', '下载升级包', '', 'system/upgrade/download', '', '_self', '0', '0', '1', '1', '1', '1491395830');
INSERT INTO `c_system_menu` VALUES ('84', '0', '6', 'system', '数据库管理', 'aicon ai-shujukuguanli', 'system/database/index', '', '_self', '6', '0', '1', '1', '1', '1491461136');
INSERT INTO `c_system_menu` VALUES ('85', '0', '84', 'system', '备份数据库', '', 'system/database/export', '', '_self', '0', '0', '1', '1', '1', '1491461250');
INSERT INTO `c_system_menu` VALUES ('86', '0', '84', 'system', '恢复数据库', '', 'system/database/import', '', '_self', '0', '0', '1', '1', '1', '1491461315');
INSERT INTO `c_system_menu` VALUES ('87', '0', '84', 'system', '优化数据库', '', 'system/database/optimize', '', '_self', '0', '0', '1', '1', '1', '1491467000');
INSERT INTO `c_system_menu` VALUES ('88', '0', '84', 'system', '删除备份', '', 'system/database/del', '', '_self', '0', '0', '1', '1', '1', '1491467058');
INSERT INTO `c_system_menu` VALUES ('89', '0', '84', 'system', '修复数据库', '', 'system/database/repair', '', '_self', '0', '0', '1', '1', '1', '1491880879');
INSERT INTO `c_system_menu` VALUES ('90', '0', '21', 'system', '设置默认等级', '', 'system/member/setdefault', '', '_self', '0', '0', '1', '1', '1', '1491966585');
INSERT INTO `c_system_menu` VALUES ('91', '0', '10', 'system', '数据库配置', '', 'system/system/index', 'group=databases', '_self', '5', '0', '1', '0', '1', '1492072213');
INSERT INTO `c_system_menu` VALUES ('92', '0', '17', 'system', '模块打包', '', 'system/module/package', '', '_self', '7', '0', '1', '1', '1', '1492134693');
INSERT INTO `c_system_menu` VALUES ('93', '0', '18', 'system', '插件打包', '', 'system/plugins/package', '', '_self', '0', '0', '1', '1', '1', '1492134743');
INSERT INTO `c_system_menu` VALUES ('94', '0', '17', 'system', '主题管理', '', 'system/module/theme', '', '_self', '8', '0', '1', '1', '1', '1492433470');
INSERT INTO `c_system_menu` VALUES ('95', '0', '17', 'system', '设置默认主题', '', 'system/module/setdefaulttheme', '', '_self', '9', '0', '1', '1', '1', '1492433618');
INSERT INTO `c_system_menu` VALUES ('96', '0', '17', 'system', '删除主题', '', 'system/module/deltheme', '', '_self', '10', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('97', '0', '6', 'system', '语言包管理', '', 'system/language/index', '', '_self', '9', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('98', '0', '97', 'system', '添加语言包', '', 'system/language/add', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('99', '0', '97', 'system', '修改语言包', '', 'system/language/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('100', '0', '97', 'system', '删除语言包', '', 'system/language/del', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('101', '0', '97', 'system', '排序设置', '', 'system/language/sort', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('102', '0', '97', 'system', '状态设置', '', 'system/language/status', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('103', '0', '16', 'system', '收藏夹图标上传', '', 'system/annex/favicon', '', '_self', '3', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('104', '0', '17', 'system', '导入模块', '', 'system/module/import', '', '_self', '11', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('105', '0', '4', 'system', '后台首页', '', 'system/index/welcome', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('106', '0', '4', 'system', '布局切换', '', 'system/user/iframe', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('107', '0', '15', 'system', '删除日志', '', 'system/log/del', 'table=admin_log', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('108', '0', '15', 'system', '清空日志', '', 'system/log/clear', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('109', '0', '17', 'system', '编辑模块', '', 'system/module/edit', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('110', '0', '17', 'system', '模块图标上传', '', 'system/module/icon', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('111', '0', '18', 'system', '导入插件', '', 'system/plugins/import', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('112', '0', '4', 'system', '钩子插件状态', '', 'system/hook/hookPluginsStatus', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('113', '0', '4', 'system', '设置主题', '', 'system/user/setTheme', '', '_self', '100', '0', '1', '0', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('114', '0', '8', 'system', '应用市场', 'aicon ai-app-store', 'system/store/index', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('115', '0', '114', 'system', '安装应用', '', 'system/store/install', '', '_self', '0', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('116', '0', '21', 'system', '重置密码', '', 'system/member/resetPwd', '', '_self', '6', '0', '1', '1', '1', '1490315067');
INSERT INTO `c_system_menu` VALUES ('117', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('118', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('119', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('120', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('121', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('122', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('123', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('124', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('125', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('126', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('127', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('128', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('129', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('130', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('131', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('132', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('133', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('134', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('135', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('136', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('137', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('138', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('139', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('140', '0', '4', 'system', '预留占位', '', '', '', '_self', '100', '0', '1', '1', '0', '1490315067');
INSERT INTO `c_system_menu` VALUES ('141', '0', '0', 'admin', '后台管理', 'aicon ai-shezhi', 'admin', '', '_self', '1', '0', '0', '1', '1', '1583230546');
INSERT INTO `c_system_menu` VALUES ('142', '0', '141', 'admin', '首页管理', 'aicon ai-shouyeshouye', 'admin/index/default', '', '_self', '0', '0', '0', '1', '1', '1583230825');
INSERT INTO `c_system_menu` VALUES ('143', '0', '142', 'admin', '轮播广告', 'aicon ai-shuaxin2', 'admin/banner/index', '', '_self', '0', '0', '0', '1', '1', '1583230968');
INSERT INTO `c_system_menu` VALUES ('144', '0', '150', 'admin', '产品分类', 'typcn typcn-th-small', 'admin/category/index', '', '_self', '0', '0', '0', '1', '1', '1583292365');
INSERT INTO `c_system_menu` VALUES ('145', '0', '150', 'admin', '全部产品', 'aicon ai-systemmenu', 'admin/product/index', '', '_self', '0', '0', '0', '1', '1', '1583293766');
INSERT INTO `c_system_menu` VALUES ('146', '0', '156', 'admin', '实训室列表', 'typcn typcn-pin-outline', 'admin/laboratory/index', '', '_self', '1', '0', '0', '1', '1', '1583399333');
INSERT INTO `c_system_menu` VALUES ('147', '0', '156', 'admin', '实训室系列视频', 'typcn typcn-video', 'admin/laboratoryVideo/index', '', '_self', '2', '0', '0', '1', '1', '1583478657');
INSERT INTO `c_system_menu` VALUES ('148', '0', '141', 'admin', '案例管理', 'aicon ai-mokuaiguanli1', 'admin/cases/default', '', '_self', '3', '0', '0', '1', '1', '1583748569');
INSERT INTO `c_system_menu` VALUES ('149', '0', '148', 'admin', '案例分类', 'aicon ai-caidan', 'admin/caseCategory/index', '', '_self', '0', '0', '0', '1', '1', '1583748595');
INSERT INTO `c_system_menu` VALUES ('150', '0', '141', 'admin', '产品管理', 'fa fa-clipboard', 'admin/product/default', '', '_self', '2', '0', '0', '1', '0', '1583824811');
INSERT INTO `c_system_menu` VALUES ('151', '0', '148', 'admin', '案例列表', 'fa fa-th-list', 'admin/cases/index', '', '_self', '0', '0', '0', '1', '1', '1583826861');
INSERT INTO `c_system_menu` VALUES ('152', '0', '141', 'admin', '视频库管理', 'fa fa-file-video-o', 'admin/video/default', '', '_self', '4', '0', '0', '1', '1', '1583911420');
INSERT INTO `c_system_menu` VALUES ('153', '0', '152', 'admin', '视频库分类', 'typcn typcn-th-small-outline', 'admin/videoCategory/index', '', '_self', '0', '0', '0', '1', '1', '1583911481');
INSERT INTO `c_system_menu` VALUES ('154', '0', '152', 'admin', '视频库', 'fa fa-video-camera', 'admin/video/index', '', '_self', '0', '0', '0', '1', '1', '1583911544');
INSERT INTO `c_system_menu` VALUES ('155', '0', '152', 'admin', '设置主推视频', 'aicon ai-tishi', 'admin/video/main', '', '_self', '0', '0', '0', '1', '1', '1583981596');
INSERT INTO `c_system_menu` VALUES ('156', '0', '141', 'admin', '实训室管理', 'aicon ai-peizhiguanli', 'admin/laboratory/default', '', '_self', '1', '0', '0', '1', '1', '1584066685');
INSERT INTO `c_system_menu` VALUES ('157', '0', '156', 'admin', '实训室分类', 'aicon ai-quanping1', 'admin/laboratoryCategory/index', '', '_self', '0', '0', '0', '1', '1', '1584093382');
INSERT INTO `c_system_menu` VALUES ('158', '0', '141', 'admin', '服务管理', 'aicon ai-chu', 'admin/feedback/default', '', '_self', '5', '0', '0', '1', '1', '1584174310');
INSERT INTO `c_system_menu` VALUES ('159', '0', '158', 'admin', '反馈列表', 'aicon ai-caidan', 'admin/feedback/index', '', '_self', '0', '0', '0', '1', '1', '1584174346');
INSERT INTO `c_system_menu` VALUES ('160', '0', '158', 'admin', '公司简介', 'typcn typcn-edit', 'admin/company/index', '', '_self', '0', '0', '0', '1', '1', '1584175237');
INSERT INTO `c_system_menu` VALUES ('161', '0', '158', 'admin', '联系我们', 'typcn typcn-phone-outline', 'admin/company/telindex', '', '_self', '0', '0', '0', '1', '1', '1584177447');

-- -----------------------------
-- Table structure for `c_system_menu_lang`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_menu_lang`;
CREATE TABLE `c_system_menu_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL DEFAULT '' COMMENT '标题',
  `lang` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '语言包',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8 COMMENT='[系统] 管理菜单语言包';

-- -----------------------------
-- Records of `c_system_menu_lang`
-- -----------------------------
INSERT INTO `c_system_menu_lang` VALUES ('131', '1', '首页', '1');
INSERT INTO `c_system_menu_lang` VALUES ('132', '2', '系统', '1');
INSERT INTO `c_system_menu_lang` VALUES ('133', '3', '插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('134', '4', '快捷菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('135', '5', '插件列表', '1');
INSERT INTO `c_system_menu_lang` VALUES ('136', '6', '系统基础', '1');
INSERT INTO `c_system_menu_lang` VALUES ('137', '7', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('138', '8', '系统扩展', '1');
INSERT INTO `c_system_menu_lang` VALUES ('139', '9', '开发专用', '1');
INSERT INTO `c_system_menu_lang` VALUES ('140', '10', '系统设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('141', '11', '配置管理', '1');
INSERT INTO `c_system_menu_lang` VALUES ('142', '12', '系统菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('143', '13', '管理员角色', '1');
INSERT INTO `c_system_menu_lang` VALUES ('144', '14', '系统管理员', '1');
INSERT INTO `c_system_menu_lang` VALUES ('145', '15', '系统日志', '1');
INSERT INTO `c_system_menu_lang` VALUES ('146', '16', '附件管理', '1');
INSERT INTO `c_system_menu_lang` VALUES ('147', '17', '本地模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('148', '18', '本地插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('149', '19', '插件钩子', '1');
INSERT INTO `c_system_menu_lang` VALUES ('150', '20', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('151', '21', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('152', '22', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('153', '23', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('154', '24', '后台首页', '1');
INSERT INTO `c_system_menu_lang` VALUES ('155', '25', '清空缓存', '1');
INSERT INTO `c_system_menu_lang` VALUES ('156', '26', '添加菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('157', '27', '修改菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('158', '28', '删除菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('159', '29', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('160', '30', '排序设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('161', '31', '添加快捷菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('162', '32', '导出菜单', '1');
INSERT INTO `c_system_menu_lang` VALUES ('163', '33', '添加角色', '1');
INSERT INTO `c_system_menu_lang` VALUES ('164', '34', '修改角色', '1');
INSERT INTO `c_system_menu_lang` VALUES ('165', '35', '删除角色', '1');
INSERT INTO `c_system_menu_lang` VALUES ('166', '36', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('167', '37', '添加管理员', '1');
INSERT INTO `c_system_menu_lang` VALUES ('168', '38', '修改管理员', '1');
INSERT INTO `c_system_menu_lang` VALUES ('169', '39', '删除管理员', '1');
INSERT INTO `c_system_menu_lang` VALUES ('170', '40', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('171', '41', '个人信息设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('172', '42', '安装插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('173', '43', '卸载插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('174', '44', '删除插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('175', '45', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('176', '46', '生成插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('177', '47', '运行插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('178', '48', '更新插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('179', '49', '插件配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('180', '50', '添加钩子', '1');
INSERT INTO `c_system_menu_lang` VALUES ('181', '51', '修改钩子', '1');
INSERT INTO `c_system_menu_lang` VALUES ('182', '52', '删除钩子', '1');
INSERT INTO `c_system_menu_lang` VALUES ('183', '53', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('184', '54', '插件排序', '1');
INSERT INTO `c_system_menu_lang` VALUES ('185', '55', '添加配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('186', '56', '修改配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('187', '57', '删除配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('188', '58', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('189', '59', '排序设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('190', '60', '基础配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('191', '61', '系统配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('192', '62', '上传配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('193', '63', '开发配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('194', '64', '生成模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('195', '65', '安装模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('196', '66', '卸载模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('197', '67', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('198', '68', '设置默认模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('199', '69', '删除模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('200', '70', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('201', '71', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('202', '72', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('203', '73', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('204', '74', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('205', '75', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('206', '76', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('207', '77', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('208', '78', '附件上传', '1');
INSERT INTO `c_system_menu_lang` VALUES ('209', '79', '删除附件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('210', '80', '框架升级', '1');
INSERT INTO `c_system_menu_lang` VALUES ('211', '81', '获取升级列表', '1');
INSERT INTO `c_system_menu_lang` VALUES ('212', '82', '安装升级包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('213', '83', '下载升级包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('214', '84', '数据库管理', '1');
INSERT INTO `c_system_menu_lang` VALUES ('215', '85', '备份数据库', '1');
INSERT INTO `c_system_menu_lang` VALUES ('216', '86', '恢复数据库', '1');
INSERT INTO `c_system_menu_lang` VALUES ('217', '87', '优化数据库', '1');
INSERT INTO `c_system_menu_lang` VALUES ('218', '88', '删除备份', '1');
INSERT INTO `c_system_menu_lang` VALUES ('219', '89', '修复数据库', '1');
INSERT INTO `c_system_menu_lang` VALUES ('220', '90', '设置默认等级', '1');
INSERT INTO `c_system_menu_lang` VALUES ('221', '91', '数据库配置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('222', '92', '模块打包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('223', '93', '插件打包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('224', '94', '主题管理', '1');
INSERT INTO `c_system_menu_lang` VALUES ('225', '95', '设置默认主题', '1');
INSERT INTO `c_system_menu_lang` VALUES ('226', '96', '删除主题', '1');
INSERT INTO `c_system_menu_lang` VALUES ('227', '97', '语言包管理', '1');
INSERT INTO `c_system_menu_lang` VALUES ('228', '98', '添加语言包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('229', '99', '修改语言包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('230', '100', '删除语言包', '1');
INSERT INTO `c_system_menu_lang` VALUES ('231', '101', '排序设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('232', '102', '状态设置', '1');
INSERT INTO `c_system_menu_lang` VALUES ('233', '103', '收藏夹图标上传', '1');
INSERT INTO `c_system_menu_lang` VALUES ('234', '104', '导入模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('235', '105', '后台首页', '1');
INSERT INTO `c_system_menu_lang` VALUES ('236', '106', '布局切换', '1');
INSERT INTO `c_system_menu_lang` VALUES ('237', '107', '删除日志', '1');
INSERT INTO `c_system_menu_lang` VALUES ('238', '108', '清空日志', '1');
INSERT INTO `c_system_menu_lang` VALUES ('239', '109', '编辑模块', '1');
INSERT INTO `c_system_menu_lang` VALUES ('240', '110', '模块图标上传', '1');
INSERT INTO `c_system_menu_lang` VALUES ('241', '111', '导入插件', '1');
INSERT INTO `c_system_menu_lang` VALUES ('242', '112', '钩子插件状态', '1');
INSERT INTO `c_system_menu_lang` VALUES ('243', '113', '设置主题', '1');
INSERT INTO `c_system_menu_lang` VALUES ('244', '114', '应用市场', '1');
INSERT INTO `c_system_menu_lang` VALUES ('245', '115', '安装应用', '1');
INSERT INTO `c_system_menu_lang` VALUES ('246', '116', '重置密码', '1');
INSERT INTO `c_system_menu_lang` VALUES ('247', '117', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('248', '118', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('249', '119', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('250', '120', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('251', '121', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('252', '122', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('253', '123', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('254', '124', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('255', '125', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('256', '126', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('257', '127', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('258', '128', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('259', '129', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('260', '130', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('261', '131', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('262', '132', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('263', '133', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('264', '134', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('265', '135', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('266', '136', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('267', '137', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('268', '138', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('269', '139', '预留占位', '1');
INSERT INTO `c_system_menu_lang` VALUES ('270', '140', '预留占位', '1');

-- -----------------------------
-- Table structure for `c_system_module`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_module`;
CREATE TABLE `c_system_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '系统模块',
  `name` varchar(50) NOT NULL COMMENT '模块名(英文)',
  `identifier` varchar(100) NOT NULL COMMENT '模块标识(模块名(字母).开发者标识.module)',
  `title` varchar(50) NOT NULL COMMENT '模块标题',
  `intro` varchar(255) NOT NULL COMMENT '模块简介',
  `author` varchar(100) NOT NULL COMMENT '作者',
  `icon` varchar(80) NOT NULL DEFAULT 'aicon ai-mokuaiguanli' COMMENT '图标',
  `version` varchar(20) NOT NULL COMMENT '版本号',
  `url` varchar(255) NOT NULL COMMENT '链接',
  `sort` int(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未安装，1未启用，2已启用',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '默认模块(只能有一个)',
  `config` text NOT NULL COMMENT '配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '应用市场ID(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `theme` varchar(50) NOT NULL DEFAULT 'default' COMMENT '主题模板',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='[系统] 模块';

-- -----------------------------
-- Records of `c_system_module`
-- -----------------------------
INSERT INTO `c_system_module` VALUES ('1', '1', 'system', 'system.hisiphp.module', '系统管理模块', '系统核心模块，用于后台各项管理功能模块及功能拓展', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `c_system_module` VALUES ('2', '1', 'index', 'index.hisiphp.module', '默认模块', '推荐使用扩展模块作为默认首页。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `c_system_module` VALUES ('3', '1', 'install', 'install.hisiphp.module', '系统安装模块', '系统安装模块，勿动。', 'HisiPHP官方出品', '', '1.0.0', 'http://www.hisiphp.com', '0', '2', '0', '', '0', '', 'default', '1489998096', '1489998096');
INSERT INTO `c_system_module` VALUES ('4', '0', 'admin', 'admin', '后台管理', '后台所有管理', 'Peng', '/static/admin/admin.png', '1.0.0', '', '0', '2', '0', '', '0', '', 'default', '1583230533', '1583230533');

-- -----------------------------
-- Table structure for `c_system_plugins`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_plugins`;
CREATE TABLE `c_system_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(32) NOT NULL COMMENT '插件名称(英文)',
  `title` varchar(32) NOT NULL COMMENT '插件标题',
  `icon` varchar(64) NOT NULL COMMENT '图标',
  `intro` text NOT NULL COMMENT '插件简介',
  `author` varchar(32) NOT NULL COMMENT '作者',
  `url` varchar(255) NOT NULL COMMENT '作者主页',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `config` text NOT NULL COMMENT '插件配置',
  `app_id` varchar(30) NOT NULL DEFAULT '0' COMMENT '来源(0本地)',
  `app_keys` varchar(200) DEFAULT '' COMMENT '应用秘钥',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='[系统] 插件表';

-- -----------------------------
-- Records of `c_system_plugins`
-- -----------------------------
INSERT INTO `c_system_plugins` VALUES ('1', '1', 'hisiphp', '系统基础信息', '/static/plugins/hisiphp/hisiphp.png', '后台首页展示系统基础信息和开发团队信息', 'HisiPHP', 'http://www.hisiphp.com', '1.0.0', 'hisiphp.hisiphp.plugins', '', '0', '', '1509379331', '1509379331', '0', '2');

-- -----------------------------
-- Table structure for `c_system_role`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_role`;
CREATE TABLE `c_system_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `intro` varchar(200) NOT NULL COMMENT '角色简介',
  `auth` text NOT NULL COMMENT '角色权限',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='[系统] 管理角色';

-- -----------------------------
-- Records of `c_system_role`
-- -----------------------------
INSERT INTO `c_system_role` VALUES ('1', '超级管理员', '拥有系统最高权限', '0', '1489411760', '0', '1');
INSERT INTO `c_system_role` VALUES ('2', '系统管理员', '拥有系统管理员权限', '[\"1\",\"4\",\"25\",\"24\",\"2\",\"6\",\"10\",\"60\",\"61\",\"62\",\"63\",\"91\",\"11\",\"55\",\"56\",\"57\",\"58\",\"59\",\"12\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\",\"32\",\"13\",\"33\",\"34\",\"35\",\"36\",\"14\",\"37\",\"38\",\"39\",\"40\",\"41\",\"16\",\"78\",\"79\",\"84\",\"85\",\"86\",\"87\",\"88\",\"89\",\"7\",\"20\",\"75\",\"76\",\"77\",\"21\",\"90\",\"70\",\"71\",\"72\",\"73\",\"74\",\"8\",\"17\",\"65\",\"66\",\"67\",\"68\",\"94\",\"95\",\"18\",\"42\",\"43\",\"45\",\"47\",\"48\",\"49\",\"19\",\"80\",\"81\",\"82\",\"83\",\"9\",\"22\",\"23\",\"3\",\"5\"]', '1489411760', '1507731116', '1');
INSERT INTO `c_system_role` VALUES ('3', '普通管理员', '普通管理员', '{\"0\":\"1\",\"1\":\"4\",\"2\":\"25\",\"4\":\"24\",\"6\":\"106\",\"8\":\"113\"}', '1507737902', '1542075415', '1');

-- -----------------------------
-- Table structure for `c_system_user`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_user`;
CREATE TABLE `c_system_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(64) NOT NULL,
  `nick` varchar(50) NOT NULL COMMENT '昵称',
  `mobile` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `auth` text NOT NULL COMMENT '权限',
  `iframe` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0默认，1框架',
  `theme` varchar(50) NOT NULL DEFAULT 'default' COMMENT '主题',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `last_login_ip` varchar(128) NOT NULL COMMENT '最后登陆IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='[系统] 管理用户';

-- -----------------------------
-- Records of `c_system_user`
-- -----------------------------
INSERT INTO `c_system_user` VALUES ('1', '1', 'admin', '$2y$10$Cjp1MGGKwMYvX358SEEj0uo7BeWWNv1vqdupgpklQbmJnb49hO1Ji', '超级管理员', '', '', '', '0', '3', '1', '27.188.252.74', '1584585967', '1583230494', '1584585967');

-- -----------------------------
-- Table structure for `c_system_user_role`
-- -----------------------------
DROP TABLE IF EXISTS `c_system_user_role`;
CREATE TABLE `c_system_user_role` (
  `user_id` int(11) unsigned NOT NULL,
  `role_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理员角色索引';

-- -----------------------------
-- Records of `c_system_user_role`
-- -----------------------------
INSERT INTO `c_system_user_role` VALUES ('1', '1');

-- -----------------------------
-- Table structure for `c_token`
-- -----------------------------
DROP TABLE IF EXISTS `c_token`;
CREATE TABLE `c_token` (
  `token` varchar(128) NOT NULL DEFAULT '' COMMENT 'Token',
  `tag` varchar(50) DEFAULT '' COMMENT '标签',
  `value` varchar(30) NOT NULL DEFAULT '' COMMENT '映射的值',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='token表';


-- -----------------------------
-- Table structure for `c_video_category`
-- -----------------------------
DROP TABLE IF EXISTS `c_video_category`;
CREATE TABLE `c_video_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '分类名称',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `c_video_category`
-- -----------------------------
INSERT INTO `c_video_category` VALUES ('4', '新能源', '1584066158');
INSERT INTO `c_video_category` VALUES ('2', '变速箱系统', '1584065860');
INSERT INTO `c_video_category` VALUES ('3', '发动机系统', '1584065903');

-- -----------------------------
-- Table structure for `c_video_comment`
-- -----------------------------
DROP TABLE IF EXISTS `c_video_comment`;
CREATE TABLE `c_video_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v_id` int(11) DEFAULT '0' COMMENT '视频资源库ID',
  `u_id` int(11) DEFAULT '0' COMMENT '评论人',
  `content` text COMMENT '评论内容',
  `p_id` int(11) DEFAULT '0' COMMENT '父级评论ID',
  `c_time` varchar(255) DEFAULT '' COMMENT '评论时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `c_video_main`
-- -----------------------------
DROP TABLE IF EXISTS `c_video_main`;
CREATE TABLE `c_video_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主推视频ID',
  `data_id` int(11) DEFAULT '0' COMMENT '视频ID',
  `image` varchar(100) DEFAULT '' COMMENT '图片',
  `c_time` varchar(11) DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `c_video_main`
-- -----------------------------
INSERT INTO `c_video_main` VALUES ('1', '4', '/upload/videomain/image/ba/dcfc8b186da384ca9cddb99bf70892.jpg', '1584582910');
INSERT INTO `c_video_main` VALUES ('2', '1', '/upload/videomain/image/53/ce7743889e9ce3d1bcfcba5936a8bf.jpg', '1584582890');

-- -----------------------------
-- Table structure for `c_videos`
-- -----------------------------
DROP TABLE IF EXISTS `c_videos`;
CREATE TABLE `c_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vc_id` int(11) DEFAULT '0' COMMENT '分类ID',
  `video_name` varchar(100) DEFAULT '' COMMENT '视频名称',
  `video_qrcode` varchar(100) DEFAULT '' COMMENT '视频二维码地址',
  `image` varchar(100) DEFAULT '' COMMENT '主图',
  `video` varchar(100) DEFAULT '' COMMENT '视频地址',
  `introduction` text COMMENT '简介',
  `watch_number` int(11) DEFAULT '0' COMMENT '观看次数',
  `share_number` int(11) DEFAULT '0' COMMENT '分享次数',
  `fabulous_number` int(11) DEFAULT '0' COMMENT '点赞次数',
  `type` int(11) DEFAULT '0' COMMENT '类别1维修案例2产品讲解',
  `c_time` varchar(11) DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `c_videos`
-- -----------------------------
INSERT INTO `c_videos` VALUES ('1', '4', '卡罗拉混动视频', '', '/upload/video/image/9a/01ae3f3c1335dcd52d484beb1967b9.jpg', '/upload/laboratory/video/20200318/fc9f1dd14cc61db0c431c37838b103b2.mp4', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/video/image/d5/c8866dc9b4ab936c895aec89380102.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;', '85', '0', '0', '2', '1584582144');
INSERT INTO `c_videos` VALUES ('2', '4', '特斯拉底盘电机系统', '', '/upload/video/image/86/629d15134c91e5492fa138a8ca6fca.jpg', '/upload/laboratory/video/20200319/294a489676ae52e7e0575044b6eb5b08.mp4', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/video/image/76/fba63d92367e48a801e3e9fc712879.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;/p&gt;', '76', '0', '1', '1', '1584582435');
INSERT INTO `c_videos` VALUES ('4', '4', '吉利纯电动电池系统', '', '/upload/video/image/b9/e52a0643f492102c3f89e3c2eed46b.jpg', '/upload/laboratory/video/20200319/244d2559727f370ed785e0d7bb88c25d.mp4', '&lt;p&gt;&lt;img src=&quot;http://cmf.qc110.cn/upload/video/image/c1/617534febe9d369f4dcdec4459e987.jpg&quot; alt=&quot;undefined&quot;&gt;&lt;br&gt;&lt;/p&gt;', '76', '0', '0', '2', '1584582408');
